import 'package:flutter/material.dart';

import '../../core/widgets/section_card.dart';
import '../../data/models/trade.dart';
import '../../data/repositories/trade_store.dart';
import '../reports/widgets/simple_charts.dart';
import '../trades/trade_details_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);

    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final stats = store.stats(ReportRange.week);
        final trades = store.trades.take(4).toList();

        return Scaffold(
          appBar: AppBar(
            title: const Text('داشبورد'),
            actions: [
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.notifications_none_rounded),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
            children: [
              Row(
                children: [
                  Expanded(
                    child: StatTile(
                      title: 'سود/ضرر هفته',
                      value: '${stats.netProfitLoss.toStringAsFixed(1)} دلار',
                      icon: Icons.account_balance_wallet_rounded,
                      positive: stats.netProfitLoss >= 0,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: StatTile(
                      title: 'Win Rate',
                      value: '${stats.winRate.toStringAsFixed(0)}٪',
                      icon: Icons.percent_rounded,
                      positive: stats.winRate >= 50,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: StatTile(
                      title: 'کل معاملات',
                      value: '${stats.total}',
                      icon: Icons.timeline_rounded,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: StatTile(
                      title: 'برد / باخت',
                      value: '${stats.wins} / ${stats.losses}',
                      icon: Icons.swap_vert_rounded,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'روند عملکرد',
                subtitle: 'نمودار نمونه بر اساس معاملات ثبت‌شده',
                child: SizedBox(
                  height: 190,
                  child: EquityLineChart(trades: store.trades),
                ),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'آخرین معاملات',
                child: Column(
                  children: trades.map((trade) {
                    return _RecentTradeTile(trade: trade);
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _RecentTradeTile extends StatelessWidget {
  const _RecentTradeTile({required this.trade});

  final Trade trade;

  @override
  Widget build(BuildContext context) {
    final pnlColor = trade.profitLoss >= 0 ? const Color(0xFF22C55E) : const Color(0xFFEF4444);

    return ListTile(
      contentPadding: EdgeInsets.zero,
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => TradeDetailsScreen(trade: trade)),
        );
      },
      leading: CircleAvatar(
        backgroundColor: const Color(0xFF0F172A),
        child: Icon(
          trade.direction == TradeDirection.buy ? Icons.trending_up_rounded : Icons.trending_down_rounded,
          color: pnlColor,
        ),
      ),
      title: Text(trade.symbol, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text('${trade.market} • ${trade.timeframe} • ${statusLabel(trade.status)}'),
      trailing: Text(
        '${trade.profitLoss.toStringAsFixed(1)}',
        style: TextStyle(color: pnlColor, fontWeight: FontWeight.w900),
      ),
    );
  }
}
