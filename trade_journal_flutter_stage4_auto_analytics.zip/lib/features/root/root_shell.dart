import 'package:flutter/material.dart';

import '../dashboard/dashboard_screen.dart';
import '../profile/profile_screen.dart';
import '../reports/reports_screen.dart';
import '../support/support_screen.dart';
import '../trades/trade_form_screen.dart';
import '../trades/trade_list_screen.dart';

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _selectedIndex = 0;

  final _screens = const [
    DashboardScreen(),
    TradeListScreen(),
    ReportsScreen(),
    SupportScreen(),
    ProfileScreen(),
  ];

  void _openNewTrade() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const TradeFormScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      floatingActionButton: _selectedIndex == 1 || _selectedIndex == 0
          ? FloatingActionButton.extended(
              onPressed: _openNewTrade,
              icon: const Icon(Icons.add_rounded),
              label: const Text('معامله جدید'),
            )
          : null,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_rounded), label: 'داشبورد'),
          BottomNavigationBarItem(icon: Icon(Icons.list_alt_rounded), label: 'معاملات'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart_rounded), label: 'گزارش'),
          BottomNavigationBarItem(icon: Icon(Icons.support_agent_rounded), label: 'پشتیبانی'),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'پروفایل'),
        ],
      ),
    );
  }
}
