import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../data/models/trade.dart';

class EquityLineChart extends StatelessWidget {
  const EquityLineChart({super.key, required this.trades});

  final List<Trade> trades;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _EquityLineChartPainter(trades: trades),
      child: const SizedBox.expand(),
    );
  }
}

class ProfitBarChart extends StatelessWidget {
  const ProfitBarChart({super.key, required this.trades});

  final List<Trade> trades;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _ProfitBarChartPainter(trades: trades),
      child: const SizedBox.expand(),
    );
  }
}

class _EquityLineChartPainter extends CustomPainter {
  _EquityLineChartPainter({required this.trades});

  final List<Trade> trades;

  @override
  void paint(Canvas canvas, Size size) {
    final axisPaint = Paint()
      ..color = const Color(0xFF253047)
      ..strokeWidth = 1;
    final linePaint = Paint()
      ..color = const Color(0xFF3B82F6)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final fillPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0x663B82F6), Color(0x003B82F6)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    for (int i = 0; i < 5; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), axisPaint);
    }

    final sorted = trades.where((trade) => trade.isClosed).toList()
      ..sort((a, b) => a.entryDate.compareTo(b.entryDate));
    if (sorted.isEmpty) return;

    final values = <double>[];
    double equity = 0;
    for (final trade in sorted) {
      equity += trade.profitLoss;
      values.add(equity);
    }

    if (values.length == 1) {
      values.add(values.first);
    }

    final minValue = values.reduce(math.min);
    final maxValue = values.reduce(math.max);
    final range = (maxValue - minValue).abs() < 0.01 ? 1 : maxValue - minValue;

    Offset pointAt(int index) {
      final x = size.width * index / (values.length - 1);
      final normalized = (values[index] - minValue) / range;
      final y = size.height - (normalized * size.height * 0.78) - (size.height * 0.1);
      return Offset(x, y);
    }

    final path = Path()..moveTo(pointAt(0).dx, pointAt(0).dy);
    for (int i = 1; i < values.length; i++) {
      path.lineTo(pointAt(i).dx, pointAt(i).dy);
    }

    final fillPath = Path.from(path)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    canvas.drawPath(fillPath, fillPaint);
    canvas.drawPath(path, linePaint);

    final dotPaint = Paint()..color = const Color(0xFFFFFFFF);
    for (int i = 0; i < values.length; i++) {
      final point = pointAt(i);
      canvas.drawCircle(point, 4, dotPaint);
      canvas.drawCircle(point, 2.4, Paint()..color = const Color(0xFF3B82F6));
    }
  }

  @override
  bool shouldRepaint(covariant _EquityLineChartPainter oldDelegate) => oldDelegate.trades != trades;
}

class _ProfitBarChartPainter extends CustomPainter {
  _ProfitBarChartPainter({required this.trades});

  final List<Trade> trades;

  @override
  void paint(Canvas canvas, Size size) {
    final closed = trades.where((trade) => trade.isClosed).take(8).toList();
    if (closed.isEmpty) return;

    final maxAbs = closed.map((trade) => trade.profitLoss.abs()).reduce(math.max);
    final centerY = size.height * 0.5;
    final barWidth = size.width / (closed.length * 1.8);
    final gap = barWidth * 0.8;

    final axisPaint = Paint()
      ..color = const Color(0xFF253047)
      ..strokeWidth = 1;
    canvas.drawLine(Offset(0, centerY), Offset(size.width, centerY), axisPaint);

    for (int i = 0; i < closed.length; i++) {
      final trade = closed[i];
      final height = (maxAbs == 0 ? 0 : (trade.profitLoss.abs() / maxAbs) * (size.height * 0.42)).toDouble();
      final left = i * (barWidth + gap) + gap / 2;
      final top = trade.profitLoss >= 0 ? centerY - height : centerY;
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(left, top, barWidth, height),
        const Radius.circular(8),
      );
      final paint = Paint()..color = trade.profitLoss >= 0 ? const Color(0xFF22C55E) : const Color(0xFFEF4444);
      canvas.drawRRect(rect, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ProfitBarChartPainter oldDelegate) => oldDelegate.trades != trades;
}
