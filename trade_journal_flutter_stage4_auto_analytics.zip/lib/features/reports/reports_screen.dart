import 'package:flutter/material.dart';

import '../../core/widgets/section_card.dart';
import '../../data/models/trade.dart';
import '../../data/repositories/trade_store.dart';
import 'widgets/simple_charts.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  ReportRange _range = ReportRange.month;

  String get _rangeTitle {
    switch (_range) {
      case ReportRange.week:
        return 'هفتگی';
      case ReportRange.month:
        return 'ماهانه';
      case ReportRange.year:
        return 'سالانه';
      case ReportRange.all:
        return 'همه معاملات';
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);

    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final stats = store.stats(_range);
        final trades = store.tradesForRange(_range);

        return Scaffold(
          appBar: AppBar(title: const Text('گزارش و آمار خودکار')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
            children: [
              DropdownButtonFormField<ReportRange>(
                value: _range,
                decoration: const InputDecoration(labelText: 'بازه گزارش'),
                items: const [
                  DropdownMenuItem(value: ReportRange.week, child: Text('هفتگی')),
                  DropdownMenuItem(value: ReportRange.month, child: Text('ماهانه')),
                  DropdownMenuItem(value: ReportRange.year, child: Text('سالانه')),
                  DropdownMenuItem(value: ReportRange.all, child: Text('همه معاملات')),
                ],
                onChanged: (value) => setState(() => _range = value ?? _range),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'خلاصه خودکار $_rangeTitle',
                subtitle: 'همه این اعداد از روی معاملات ثبت‌شده محاسبه می‌شوند.',
                child: GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.25,
                  children: [
                    StatTile(title: 'کل معاملات', value: '${stats.total}', icon: Icons.timeline_rounded),
                    StatTile(title: 'باز / بسته', value: '${stats.open} / ${stats.closed}', icon: Icons.lock_open_rounded),
                    StatTile(
                      title: 'Win Rate',
                      value: '${stats.winRate.toStringAsFixed(0)}٪',
                      icon: Icons.percent_rounded,
                      positive: stats.winRate >= 50,
                    ),
                    StatTile(
                      title: 'سود خالص',
                      value: '${stats.netProfitLoss.toStringAsFixed(1)} دلار',
                      icon: Icons.account_balance_rounded,
                      positive: stats.netProfitLoss >= 0,
                    ),
                    StatTile(
                      title: 'Profit Factor',
                      value: stats.profitFactor <= 0 ? '-' : stats.profitFactor.toStringAsFixed(2),
                      icon: Icons.query_stats_rounded,
                      positive: stats.profitFactor >= 1,
                    ),
                    StatTile(
                      title: 'Expectancy',
                      value: '${stats.expectancy.toStringAsFixed(2)}',
                      icon: Icons.functions_rounded,
                      positive: stats.expectancy >= 0,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'تجزیه و تحلیل خودکار',
                subtitle: 'اپ بر اساس داده‌های معاملات نتیجه‌گیری می‌کند.',
                child: Column(
                  children: stats.insights.map((text) => _InsightTile(text: text)).toList(),
                ),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'نمودار رشد حساب',
                child: SizedBox(height: 190, child: EquityLineChart(trades: trades)),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'سود و ضرر معاملات اخیر',
                child: SizedBox(height: 180, child: ProfitBarChart(trades: trades)),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'کیفیت ریسک و خروج',
                child: Column(
                  children: [
                    _MetricRow(label: 'میانگین R:R برنامه‌ریزی‌شده', value: _rrLabel(stats.averageRiskReward)),
                    _MetricRow(label: 'میانگین R واقعی معاملات', value: '${stats.averageRealizedRiskReward.toStringAsFixed(2)}R'),
                    _MetricRow(label: 'میانگین سود هر برد', value: stats.averageWin.toStringAsFixed(2)),
                    _MetricRow(label: 'میانگین ضرر هر باخت', value: stats.averageLoss.toStringAsFixed(2)),
                    _MetricRow(label: 'Payoff Ratio', value: stats.payoffRatio <= 0 ? '-' : stats.payoffRatio.toStringAsFixed(2)),
                    _MetricRow(label: 'میانگین خروجی هر معامله', value: stats.averageProfitLoss.toStringAsFixed(2)),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'تحلیل تارگت‌ها و پلن',
                child: Column(
                  children: [
                    _ProgressRow(label: 'رسیدن به تارگت 1', value: stats.target1Rate),
                    const SizedBox(height: 14),
                    _ProgressRow(label: 'رسیدن به تارگت 2', value: stats.target2Rate),
                    const SizedBox(height: 14),
                    _ProgressRow(label: 'کامل بودن دلیل ورود و استراتژی', value: stats.planCompletionRate),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'بهترین و بدترین‌ها',
                subtitle: 'بر اساس سود/ضرر خالص همین بازه.',
                child: Column(
                  children: [
                    _PerformanceRow(title: 'بهترین نماد', item: stats.bestSymbol),
                    _PerformanceRow(title: 'ضعیف‌ترین نماد', item: stats.worstSymbol),
                    _PerformanceRow(title: 'بهترین استراتژی', item: stats.bestStrategy),
                    _PerformanceRow(title: 'ضعیف‌ترین استراتژی', item: stats.worstStrategy),
                    _PerformanceRow(title: 'بهترین تایم‌فریم', item: stats.bestTimeframe),
                    _PerformanceRow(title: 'ضعیف‌ترین تایم‌فریم', item: stats.worstTimeframe),
                    _PerformanceRow(title: 'بهترین احساس', item: stats.bestEmotion),
                    _PerformanceRow(title: 'ضعیف‌ترین احساس', item: stats.worstEmotion),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'رکوردها',
                child: Column(
                  children: [
                    _TradeRecordRow(title: 'بهترین معامله', trade: stats.bestTrade),
                    _TradeRecordRow(title: 'بدترین معامله', trade: stats.worstTrade),
                    _MetricRow(label: 'بیشترین برد پشت‌سرهم', value: '${stats.longestWinStreak}'),
                    _MetricRow(label: 'بیشترین ضرر پشت‌سرهم', value: '${stats.longestLossStreak}'),
                    _MetricRow(label: 'برد / باخت / سربه‌سر', value: '${stats.wins} / ${stats.losses} / ${stats.breakEvens}'),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _rrLabel(double value) {
    if (value <= 0) return '-';
    return '1:${value.toStringAsFixed(2)}';
  }
}

class _InsightTile extends StatelessWidget {
  const _InsightTile({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.auto_awesome_rounded, color: Color(0xFF3B82F6), size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(height: 1.7))),
        ],
      ),
    );
  }
}

class _MetricRow extends StatelessWidget {
  const _MetricRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Color(0xFFCBD5E1)))),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
          ),
        ],
      ),
    );
  }
}

class _PerformanceRow extends StatelessWidget {
  const _PerformanceRow({required this.title, required this.item});

  final String title;
  final PerformanceSummary? item;

  @override
  Widget build(BuildContext context) {
    final summary = item;
    if (summary == null) return _MetricRow(label: title, value: '-');
    final value = '${summary.label} • ${summary.netProfitLoss.toStringAsFixed(1)} • ${summary.winRate.toStringAsFixed(0)}٪';
    return _MetricRow(label: title, value: value);
  }
}

class _TradeRecordRow extends StatelessWidget {
  const _TradeRecordRow({required this.title, required this.trade});

  final String title;
  final Trade? trade;

  @override
  Widget build(BuildContext context) {
    final item = trade;
    if (item == null) return _MetricRow(label: title, value: '-');
    return _MetricRow(label: title, value: '${item.symbol} • ${item.profitLoss.toStringAsFixed(1)}');
  }
}

class _ProgressRow extends StatelessWidget {
  const _ProgressRow({required this.label, required this.value});

  final String label;
  final double value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700))),
            Text('${value.toStringAsFixed(0)}٪', style: const TextStyle(fontWeight: FontWeight.w900)),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: LinearProgressIndicator(
            minHeight: 10,
            value: (value.clamp(0, 100) as num).toDouble() / 100,
            backgroundColor: const Color(0xFF0F172A),
          ),
        ),
      ],
    );
  }
}
