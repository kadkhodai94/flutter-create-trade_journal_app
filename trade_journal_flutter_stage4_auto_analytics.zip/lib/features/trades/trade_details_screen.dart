import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/widgets/section_card.dart';
import '../../data/models/trade.dart';
import '../../data/repositories/trade_store.dart';
import 'trade_form_screen.dart';

class TradeDetailsScreen extends StatelessWidget {
  const TradeDetailsScreen({super.key, required this.trade});

  final Trade trade;

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);

    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        Trade? currentTrade;
        for (final item in store.trades) {
          if (item.id == trade.id) {
            currentTrade = item;
            break;
          }
        }
        if (currentTrade == null) {
          return const Scaffold(
            body: Center(child: Text('این معامله حذف شده است')),
          );
        }

        return _TradeDetailsBody(trade: currentTrade);
      },
    );
  }
}

class _TradeDetailsBody extends StatelessWidget {
  const _TradeDetailsBody({required this.trade});

  final Trade trade;

  Future<void> _deleteTrade(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('حذف معامله'),
          content: const Text('این معامله حذف شود؟'),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('لغو')),
            FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('حذف')),
          ],
        );
      },
    );

    if (confirmed != true || !context.mounted) return;
    AppScope.of(context).deleteTrade(trade.id);
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('معامله حذف شد')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pnlColor = trade.profitLoss >= 0 ? const Color(0xFF22C55E) : const Color(0xFFEF4444);

    return Scaffold(
      appBar: AppBar(
        title: Text(trade.symbol),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => TradeFormScreen(trade: trade)),
              );
            },
            icon: const Icon(Icons.edit_rounded),
          ),
          IconButton(
            onPressed: () => _deleteTrade(context),
            icon: const Icon(Icons.delete_outline_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          trade.symbol,
                          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
                        ),
                      ),
                      Text(
                        '${trade.profitLoss.toStringAsFixed(1)} دلار',
                        style: TextStyle(color: pnlColor, fontSize: 22, fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '${trade.market} • ${directionLabel(trade.direction)} • ${trade.timeframe} • ${statusLabel(trade.status)}',
                    style: const TextStyle(color: Color(0xFF94A3B8)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'قیمت‌ها',
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _InfoPill(label: 'ورود', value: '${trade.entryPrice}'),
                _InfoPill(label: 'خروج', value: trade.exitPrice?.toString() ?? '-'),
                _InfoPill(label: 'حد ضرر', value: '${trade.stopLoss}'),
                _InfoPill(label: 'بهترین R:R', value: trade.bestRiskRewardLabel),
                _InfoPill(label: 'R واقعی', value: trade.actualRiskRewardLabel),
                _InfoPill(label: 'حجم', value: '${trade.positionSize}'),
                _InfoPill(label: 'ریسک', value: '${trade.riskPercent}%'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'تارگت‌ها',
            child: Column(
              children: trade.targets.map((target) {
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    target.isHit ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                    color: target.isHit ? const Color(0xFF22C55E) : const Color(0xFF64748B),
                  ),
                  title: Text(target.title),
                  subtitle: Text('R:R ${trade.riskRewardLabelForTarget(target)}'),
                  trailing: Text('${target.price}', style: const TextStyle(fontWeight: FontWeight.w800)),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'تحلیل معامله',
            subtitle: 'نتیجه، تارگت‌های خورده و R واقعی به‌صورت خودکار از داده‌های معامله ساخته می‌شوند.',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _TextBlock(title: 'استراتژی', value: trade.strategy),
                _TextBlock(title: 'دلیل ورود', value: trade.reason),
                _TextBlock(title: 'احساس قبل از ورود', value: trade.emotion),
                if (trade.notes.isNotEmpty) _TextBlock(title: 'یادداشت نهایی', value: trade.notes),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'عکس‌ها و مستندات',
            subtitle: 'در این مرحله عکس‌ها روی حافظه داخلی اپ ذخیره می‌شوند.',
            child: trade.images.isEmpty
                ? const Text('هنوز تصویری ثبت نشده است.', style: TextStyle(color: Color(0xFF94A3B8)))
                : Column(
                    children: trade.images.map((image) => _ImageCard(image: image)).toList(),
                  ),
          ),
        ],
      ),
    );
  }
}

class _ImageCard extends StatelessWidget {
  const _ImageCard({required this.image});

  final TradeImageNote image;

  @override
  Widget build(BuildContext context) {
    final path = image.path;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (path != null)
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
              child: Image.file(
                File(path),
                height: 180,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const SizedBox(
                  height: 110,
                  child: Center(child: Icon(Icons.broken_image_rounded)),
                ),
              ),
            )
          else
            const SizedBox(
              height: 76,
              child: Center(child: Icon(Icons.image_rounded, color: Color(0xFF3B82F6))),
            ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(image.type, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(image.note, style: const TextStyle(color: Color(0xFF94A3B8))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoPill extends StatelessWidget {
  const _InfoPill({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 145,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _TextBlock extends StatelessWidget {
  const _TextBlock({required this.title, required this.value});

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
          const SizedBox(height: 5),
          Text(value, style: const TextStyle(height: 1.7)),
        ],
      ),
    );
  }
}
