import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../../core/widgets/section_card.dart';
import '../../data/models/trade.dart';
import '../../data/repositories/trade_store.dart';

class TradeFormScreen extends StatefulWidget {
  const TradeFormScreen({super.key, this.trade});

  final Trade? trade;

  @override
  State<TradeFormScreen> createState() => _TradeFormScreenState();
}

class _TradeFormScreenState extends State<TradeFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _picker = ImagePicker();

  final _symbol = TextEditingController(text: 'BTCUSDT');
  final _entryPrice = TextEditingController();
  final _stopLoss = TextEditingController();
  final _target1 = TextEditingController();
  final _target2 = TextEditingController();
  final _positionSize = TextEditingController();
  final _riskPercent = TextEditingController(text: '1');
  final _strategy = TextEditingController();
  final _reason = TextEditingController();
  final _notes = TextEditingController();
  final _imageNote = TextEditingController();
  final _exitPrice = TextEditingController();
  final _profitLoss = TextEditingController();

  String _market = 'کریپتو';
  String _timeframe = '15m';
  String _emotion = 'آرام';
  TradeDirection _direction = TradeDirection.buy;
  TradeStatus _status = TradeStatus.open;
  bool _target1Hit = false;
  bool _target2Hit = false;
  final List<TextEditingController> _extraTargets = [];
  final List<bool> _extraTargetHits = [];
  final List<TradeImageNote> _images = [];

  bool get _isEditing => widget.trade != null;

  @override
  void initState() {
    super.initState();
    final trade = widget.trade;
    if (trade == null) return;

    _symbol.text = trade.symbol;
    _entryPrice.text = _formatNumber(trade.entryPrice);
    _stopLoss.text = _formatNumber(trade.stopLoss);
    _positionSize.text = trade.positionSize == 0 ? '' : _formatNumber(trade.positionSize);
    _riskPercent.text = trade.riskPercent == 0 ? '' : _formatNumber(trade.riskPercent);
    _strategy.text = trade.strategy == 'ثبت نشده' ? '' : trade.strategy;
    _reason.text = trade.reason == 'ثبت نشده' ? '' : trade.reason;
    _notes.text = trade.notes;
    _exitPrice.text = trade.exitPrice == null ? '' : _formatNumber(trade.exitPrice!);
    _profitLoss.text = trade.profitLoss == 0 ? '' : _formatNumber(trade.profitLoss);

    _market = trade.market;
    _timeframe = trade.timeframe;
    _emotion = trade.emotion;
    _direction = trade.direction;
    _status = trade.status;
    _images.addAll(trade.images);

    if (trade.targets.isNotEmpty) {
      _target1.text = _formatNumber(trade.targets[0].price);
      _target1Hit = trade.targets[0].isHit;
    }
    if (trade.targets.length > 1) {
      _target2.text = _formatNumber(trade.targets[1].price);
      _target2Hit = trade.targets[1].isHit;
    }
    for (int i = 2; i < trade.targets.length; i++) {
      _extraTargets.add(TextEditingController(text: _formatNumber(trade.targets[i].price)));
      _extraTargetHits.add(trade.targets[i].isHit);
    }
  }

  @override
  void dispose() {
    _symbol.dispose();
    _entryPrice.dispose();
    _stopLoss.dispose();
    _target1.dispose();
    _target2.dispose();
    _positionSize.dispose();
    _riskPercent.dispose();
    _strategy.dispose();
    _reason.dispose();
    _notes.dispose();
    _imageNote.dispose();
    _exitPrice.dispose();
    _profitLoss.dispose();
    for (final controller in _extraTargets) {
      controller.dispose();
    }
    super.dispose();
  }

  String _formatNumber(double value) {
    if (value % 1 == 0) return value.toStringAsFixed(0);
    return value.toString();
  }

  String? _required(String? value) {
    if (value == null || value.trim().isEmpty) return 'این فیلد لازم است';
    return null;
  }

  double _doubleValue(TextEditingController controller) {
    return double.tryParse(controller.text.trim().replaceAll(',', '.')) ?? 0;
  }

  double _riskDistance() {
    final entry = _doubleValue(_entryPrice);
    final stop = _doubleValue(_stopLoss);
    if (entry == 0 || stop == 0) return 0;
    return (entry - stop).abs();
  }

  double _rewardDistance(TextEditingController targetController) {
    final entry = _doubleValue(_entryPrice);
    final target = _doubleValue(targetController);
    if (entry == 0 || target == 0) return 0;
    final reward = _direction == TradeDirection.buy ? target - entry : entry - target;
    return reward <= 0 ? 0 : reward;
  }

  String _riskRewardText(TextEditingController targetController) {
    final risk = _riskDistance();
    final reward = _rewardDistance(targetController);
    if (risk <= 0 || reward <= 0) return '-';
    return '1:${(reward / risk).toStringAsFixed(2)}';
  }

  double? _exitPriceValue() {
    if (_status == TradeStatus.open) return null;
    final exitText = _exitPrice.text.trim();
    if (exitText.isNotEmpty) return _doubleValue(_exitPrice);
    if (_status == TradeStatus.stopHit) return _doubleValue(_stopLoss);
    if (_status == TradeStatus.targetHit) {
      if (_target2.text.trim().isNotEmpty) return _doubleValue(_target2);
      if (_target1.text.trim().isNotEmpty) return _doubleValue(_target1);
    }
    return null;
  }

  double _calculatedProfitLoss() {
    final exit = _exitPriceValue();
    final entry = _doubleValue(_entryPrice);
    if (exit == null || entry == 0) return 0;
    final size = _doubleValue(_positionSize) <= 0 ? 1 : _doubleValue(_positionSize);
    final distance = _direction == TradeDirection.buy ? exit - entry : entry - exit;
    if (_status == TradeStatus.breakEven) return 0;
    return distance * size;
  }

  TradeStatus _automaticStatus(double? exit, List<TradeTarget> targets) {
    if (exit == null) return TradeStatus.open;
    final entry = _doubleValue(_entryPrice);
    final stop = _doubleValue(_stopLoss);
    if (entry == 0) return _status;
    final pnl = _calculatedProfitLoss();
    if (pnl == 0 || _status == TradeStatus.breakEven) return TradeStatus.breakEven;
    final stopped = _direction == TradeDirection.buy ? exit <= stop : exit >= stop;
    if (stopped && stop > 0) return TradeStatus.stopHit;
    final hitTarget = targets.any((target) {
      if (target.price == 0) return false;
      return _direction == TradeDirection.buy ? exit >= target.price : exit <= target.price;
    });
    if (hitTarget && pnl > 0) return TradeStatus.targetHit;
    return TradeStatus.closed;
  }

  bool _autoTargetHit(double targetPrice, double? exit) {
    if (exit == null || targetPrice == 0) return false;
    return _direction == TradeDirection.buy ? exit >= targetPrice : exit <= targetPrice;
  }

  void _addTargetField() {
    setState(() {
      _extraTargets.add(TextEditingController());
      _extraTargetHits.add(false);
    });
  }

  void _removeExtraTarget(int index) {
    setState(() {
      _extraTargets[index].dispose();
      _extraTargets.removeAt(index);
      _extraTargetHits.removeAt(index);
    });
  }

  Future<void> _pickImage() async {
    try {
      final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
      if (picked == null) return;

      final directory = await getApplicationDocumentsDirectory();
      final extension = picked.path.contains('.') ? picked.path.split('.').last : 'jpg';
      final fileName = 'trade_${DateTime.now().microsecondsSinceEpoch}.$extension';
      final savedFile = await File(picked.path).copy('${directory.path}/$fileName');

      if (!mounted) return;
      setState(() {
        _images.add(
          TradeImageNote(
            type: 'عکس معامله',
            note: _imageNote.text.trim().isEmpty ? 'بدون توضیح' : _imageNote.text.trim(),
            path: savedFile.path,
          ),
        );
        _imageNote.clear();
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('انتخاب عکس انجام نشد')),
      );
    }
  }

  void _removeImage(int index) {
    setState(() => _images.removeAt(index));
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    final store = AppScope.of(context);
    final exitPrice = _exitPriceValue();

    final rawTargets = <TradeTarget>[
      TradeTarget(title: 'تارگت 1', price: _doubleValue(_target1)),
      TradeTarget(title: 'تارگت 2', price: _doubleValue(_target2)),
      for (int i = 0; i < _extraTargets.length; i++)
        if (_extraTargets[i].text.trim().isNotEmpty)
          TradeTarget(title: 'تارگت ${i + 3}', price: _doubleValue(_extraTargets[i])),
    ];

    final targets = rawTargets
        .map((target) => target.copyWith(isHit: _autoTargetHit(target.price, exitPrice)))
        .toList();
    final calculatedStatus = _automaticStatus(exitPrice, targets);
    final isOpen = calculatedStatus == TradeStatus.open;

    final oldTrade = widget.trade;
    final trade = Trade(
      id: oldTrade?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      symbol: _symbol.text.trim().toUpperCase(),
      market: _market,
      direction: _direction,
      entryDate: oldTrade?.entryDate ?? DateTime.now(),
      exitDate: isOpen ? null : oldTrade?.exitDate ?? DateTime.now(),
      timeframe: _timeframe,
      entryPrice: _doubleValue(_entryPrice),
      stopLoss: _doubleValue(_stopLoss),
      targets: targets,
      positionSize: _doubleValue(_positionSize),
      riskPercent: _doubleValue(_riskPercent),
      strategy: _strategy.text.trim().isEmpty ? 'ثبت نشده' : _strategy.text.trim(),
      reason: _reason.text.trim().isEmpty ? 'ثبت نشده' : _reason.text.trim(),
      emotion: _emotion,
      status: calculatedStatus,
      exitPrice: isOpen ? null : exitPrice,
      profitLoss: isOpen ? 0 : _calculatedProfitLoss(),
      notes: _notes.text.trim(),
      images: List.unmodifiable(_images),
    );

    if (_isEditing) {
      store.updateTrade(trade);
    } else {
      store.addTrade(trade);
    }

    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_isEditing ? 'معامله و آمار آن خودکار به‌روزرسانی شد' : 'معامله ثبت شد و آمارها خودکار محاسبه شدند')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEditing ? 'ویرایش معامله' : 'ثبت معامله')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
          children: [
            _FormIntro(isEditing: _isEditing),
            const SizedBox(height: 12),
            SectionCard(
              title: 'ثبت سریع',
              subtitle: 'فقط اطلاعات ضروری معامله را وارد کن؛ جزئیات بیشتر اختیاری است.',
              child: Column(
                children: [
                  TextFormField(
                    controller: _symbol,
                    validator: _required,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      labelText: 'نماد',
                      hintText: 'مثلا BTCUSDT',
                      prefixIcon: Icon(Icons.show_chart_rounded),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<TradeDirection>(
                          value: _direction,
                          decoration: const InputDecoration(labelText: 'نوع'),
                          items: const [
                            DropdownMenuItem(value: TradeDirection.buy, child: Text('خرید')),
                            DropdownMenuItem(value: TradeDirection.sell, child: Text('فروش')),
                          ],
                          onChanged: (value) => setState(() => _direction = value ?? _direction),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: _timeframe,
                          decoration: const InputDecoration(labelText: 'تایم‌فریم'),
                          items: const [
                            DropdownMenuItem(value: '1m', child: Text('1m')),
                            DropdownMenuItem(value: '5m', child: Text('5m')),
                            DropdownMenuItem(value: '15m', child: Text('15m')),
                            DropdownMenuItem(value: '30m', child: Text('30m')),
                            DropdownMenuItem(value: '1H', child: Text('1H')),
                            DropdownMenuItem(value: '4H', child: Text('4H')),
                            DropdownMenuItem(value: 'Daily', child: Text('Daily')),
                          ],
                          onChanged: (value) => setState(() => _timeframe = value ?? _timeframe),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: _NumberField(controller: _entryPrice, label: 'ورود', onChanged: (_) => setState(() {}))),
                      const SizedBox(width: 12),
                      Expanded(child: _NumberField(controller: _stopLoss, label: 'استاپ', onChanged: (_) => setState(() {}))),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: _NumberField(controller: _target1, label: 'تارگت 1', onChanged: (_) => setState(() {}))),
                      const SizedBox(width: 12),
                      Expanded(child: _NumberField(controller: _target2, label: 'تارگت 2', onChanged: (_) => setState(() {}))),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _RiskRewardPreview(
                    risk: _riskDistance(),
                    target1Reward: _rewardDistance(_target1),
                    target2Reward: _rewardDistance(_target2),
                    target1Ratio: _riskRewardText(_target1),
                    target2Ratio: _riskRewardText(_target2),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _buildAdvancedFields(),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save_rounded),
              label: Text(_isEditing ? 'ذخیره تغییرات' : 'ثبت معامله'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAdvancedFields() {
    return Card(
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
        childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
        title: const Text('جزئیات بیشتر', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('نتیجه معامله، عکس، استراتژی، احساس و تارگت‌های اضافه'),
        initiallyExpanded: _isEditing,
        children: [
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _market,
                  decoration: const InputDecoration(labelText: 'بازار'),
                  items: const [
                    DropdownMenuItem(value: 'کریپتو', child: Text('کریپتو')),
                    DropdownMenuItem(value: 'فارکس', child: Text('فارکس')),
                    DropdownMenuItem(value: 'بورس', child: Text('بورس')),
                    DropdownMenuItem(value: 'طلا', child: Text('طلا')),
                  ],
                  onChanged: (value) => setState(() => _market = value ?? _market),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DropdownButtonFormField<TradeStatus>(
                  value: _status,
                  decoration: const InputDecoration(labelText: 'وضعیت'),
                  items: const [
                    DropdownMenuItem(value: TradeStatus.open, child: Text('باز')),
                    DropdownMenuItem(value: TradeStatus.closed, child: Text('بسته‌شده')),
                    DropdownMenuItem(value: TradeStatus.targetHit, child: Text('تارگت خورده')),
                    DropdownMenuItem(value: TradeStatus.stopHit, child: Text('استاپ خورده')),
                    DropdownMenuItem(value: TradeStatus.breakEven, child: Text('سربه‌سر')),
                  ],
                  onChanged: (value) => setState(() => _status = value ?? _status),
                ),
              ),
            ],
          ),
          if (_status != TradeStatus.open) ...[
            const SizedBox(height: 12),
            _OptionalNumberField(
              controller: _exitPrice,
              label: 'قیمت خروج؛ سود/ضرر خودکار حساب می‌شود',
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 10),
            _AutoResultPreview(
              profitLoss: _calculatedProfitLoss(),
              exitPrice: _exitPriceValue(),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _OptionalNumberField(controller: _positionSize, label: 'حجم معامله')),
              const SizedBox(width: 12),
              Expanded(child: _OptionalNumberField(controller: _riskPercent, label: 'درصد ریسک')),
            ],
          ),
          const SizedBox(height: 12),
          const _AutoAnalysisNote(),
          const SizedBox(height: 12),
          TextFormField(
            controller: _strategy,
            decoration: const InputDecoration(labelText: 'استراتژی'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _emotion,
            decoration: const InputDecoration(labelText: 'احساس قبل از معامله'),
            items: const [
              DropdownMenuItem(value: 'آرام', child: Text('آرام')),
              DropdownMenuItem(value: 'متمرکز', child: Text('متمرکز')),
              DropdownMenuItem(value: 'ترس', child: Text('ترس')),
              DropdownMenuItem(value: 'طمع', child: Text('طمع')),
              DropdownMenuItem(value: 'عجله', child: Text('عجله')),
              DropdownMenuItem(value: 'انتقام', child: Text('انتقام')),
            ],
            onChanged: (value) => setState(() => _emotion = value ?? _emotion),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _reason,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(labelText: 'دلیل ورود'),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _notes,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(labelText: 'یادداشت معامله'),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _imageNote,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'توضیح عکس',
              hintText: 'مثلا چارت قبل از ورود یا لحظه خروج',
              prefixIcon: Icon(Icons.image_rounded),
            ),
          ),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerRight,
            child: OutlinedButton.icon(
              onPressed: _pickImage,
              icon: const Icon(Icons.photo_library_rounded),
              label: const Text('انتخاب عکس معامله'),
            ),
          ),
          if (_images.isNotEmpty) ...[
            const SizedBox(height: 12),
            ...List.generate(_images.length, (index) => _ImagePreviewRow(
                  image: _images[index],
                  onRemove: () => _removeImage(index),
                )),
          ],
          const SizedBox(height: 12),
          for (int i = 0; i < _extraTargets.length; i++) ...[
            Row(
              children: [
                Expanded(child: _OptionalNumberField(controller: _extraTargets[i], label: 'تارگت ${i + 3}')),
                const SizedBox(width: 8),
                const Tooltip(
                  message: 'وضعیت تارگت بعد از قیمت خروج خودکار محاسبه می‌شود',
                  child: Icon(Icons.auto_graph_rounded),
                ),
                IconButton(
                  onPressed: () => _removeExtraTarget(i),
                  icon: const Icon(Icons.delete_outline_rounded),
                ),
              ],
            ),
            const SizedBox(height: 12),
          ],
          Align(
            alignment: Alignment.centerRight,
            child: OutlinedButton.icon(
              onPressed: _addTargetField,
              icon: const Icon(Icons.add_rounded),
              label: const Text('افزودن تارگت بیشتر'),
            ),
          ),
        ],
      ),
    );
  }
}

class _FormIntro extends StatelessWidget {
  const _FormIntro({required this.isEditing});

  final bool isEditing;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF101827),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Row(
        children: [
          Icon(isEditing ? Icons.edit_note_rounded : Icons.add_chart_rounded),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              isEditing
                  ? 'اینجا می‌تونی معامله را ویرایش کنی، نتیجه را ببندی و عکس اضافه کنی.'
                  : 'ثبت سریع معامله فعال است. نتیجه، R:R و تحلیل‌ها بعد از ثبت به‌صورت خودکار محاسبه می‌شوند.',
              style: const TextStyle(fontSize: 13, color: Color(0xFFCBD5E1)),
            ),
          ),
        ],
      ),
    );
  }
}


class _RiskRewardPreview extends StatelessWidget {
  const _RiskRewardPreview({
    required this.risk,
    required this.target1Reward,
    required this.target2Reward,
    required this.target1Ratio,
    required this.target2Ratio,
  });

  final double risk;
  final double target1Reward;
  final double target2Reward;
  final String target1Ratio;
  final String target2Ratio;

  String _distanceText(double value) {
    if (value <= 0) return '-';
    if (value % 1 == 0) return value.toStringAsFixed(0);
    return value.toStringAsFixed(4);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.balance_rounded, size: 20, color: Color(0xFF3B82F6)),
              SizedBox(width: 8),
              Text('ریسک به ریوارد', style: TextStyle(fontWeight: FontWeight.w900)),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _MiniMetric(label: 'ریسک', value: _distanceText(risk)),
              _MiniMetric(label: 'Reward تارگت 1', value: _distanceText(target1Reward)),
              _MiniMetric(label: 'Reward تارگت 2', value: _distanceText(target2Reward)),
              _MiniMetric(label: 'R:R تارگت 1', value: target1Ratio),
              _MiniMetric(label: 'R:R تارگت 2', value: target2Ratio),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniMetric extends StatelessWidget {
  const _MiniMetric({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF111827),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8))),
          const SizedBox(height: 3),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}


class _AutoResultPreview extends StatelessWidget {
  const _AutoResultPreview({required this.profitLoss, required this.exitPrice});

  final double profitLoss;
  final double? exitPrice;

  @override
  Widget build(BuildContext context) {
    final isPositive = profitLoss >= 0;
    final color = profitLoss == 0
        ? const Color(0xFF94A3B8)
        : isPositive
            ? const Color(0xFF22C55E)
            : const Color(0xFFEF4444);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Row(
        children: [
          Icon(Icons.functions_rounded, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              exitPrice == null
                  ? 'با وارد کردن قیمت خروج، سود/ضرر و وضعیت تارگت‌ها خودکار حساب می‌شود.'
                  : 'سود/ضرر خودکار: ${profitLoss.toStringAsFixed(2)}',
              style: TextStyle(color: color, fontWeight: FontWeight.w900),
            ),
          ),
        ],
      ),
    );
  }
}

class _AutoAnalysisNote extends StatelessWidget {
  const _AutoAnalysisNote();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.auto_awesome_rounded, color: Color(0xFF3B82F6)),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'وضعیت تارگت‌ها، سود/ضرر، R:R واقعی و آمار گزارش‌ها از روی ورود، استاپ، تارگت‌ها، حجم و قیمت خروج خودکار محاسبه می‌شود.',
              style: TextStyle(color: Color(0xFFCBD5E1), height: 1.6),
            ),
          ),
        ],
      ),
    );
  }
}

class _ImagePreviewRow extends StatelessWidget {
  const _ImagePreviewRow({required this.image, required this.onRemove});

  final TradeImageNote image;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final path = image.path;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: path == null
                ? Container(
                    width: 56,
                    height: 56,
                    color: const Color(0xFF111827),
                    child: const Icon(Icons.image_rounded),
                  )
                : Image.file(
                    File(path),
                    width: 56,
                    height: 56,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      width: 56,
                      height: 56,
                      color: const Color(0xFF111827),
                      child: const Icon(Icons.broken_image_rounded),
                    ),
                  ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              image.note,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Color(0xFFCBD5E1)),
            ),
          ),
          IconButton(onPressed: onRemove, icon: const Icon(Icons.close_rounded)),
        ],
      ),
    );
  }
}

class _NumberField extends StatelessWidget {
  const _NumberField({required this.controller, required this.label, this.onChanged});

  final TextEditingController controller;
  final String label;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      onChanged: onChanged,
      keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
      validator: (value) {
        if (value == null || value.trim().isEmpty) return 'لازم است';
        if (double.tryParse(value.trim().replaceAll(',', '.')) == null) return 'عدد معتبر نیست';
        return null;
      },
      decoration: InputDecoration(labelText: label),
    );
  }
}

class _OptionalNumberField extends StatelessWidget {
  const _OptionalNumberField({required this.controller, required this.label, this.onChanged});

  final TextEditingController controller;
  final String label;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      onChanged: onChanged,
      keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
      validator: (value) {
        if (value == null || value.trim().isEmpty) return null;
        if (double.tryParse(value.trim().replaceAll(',', '.')) == null) return 'عدد معتبر نیست';
        return null;
      },
      decoration: InputDecoration(labelText: label),
    );
  }
}
