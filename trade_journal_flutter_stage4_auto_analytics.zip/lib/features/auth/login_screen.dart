import 'package:flutter/material.dart';

import '../root/root_shell.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController(text: 'demo@journal.app');
  final _passwordController = TextEditingController(text: '123456');

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _enterApp() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const RootShell()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF2563EB), Color(0xFF22C55E)],
                  ),
                ),
                child: const Icon(Icons.show_chart_rounded, size: 38, color: Colors.white),
              ),
              const SizedBox(height: 24),
              const Text(
                'ژورنال معاملاتی',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              const Text(
                'معاملاتت رو ثبت کن، اشتباهاتت رو پیدا کن و رشد حساب رو با نمودار ببین.',
                style: TextStyle(color: Color(0xFF94A3B8), height: 1.8),
              ),
              const SizedBox(height: 32),
              TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'ایمیل'),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'رمز عبور'),
              ),
              const SizedBox(height: 22),
              FilledButton(
                onPressed: _enterApp,
                child: const Text('ورود به نسخه آزمایشی'),
              ),
              const SizedBox(height: 12),
              Center(
                child: TextButton(
                  onPressed: _enterApp,
                  child: const Text('ساخت حساب جدید'),
                ),
              ),
              const Spacer(),
              const Center(
                child: Text(
                  'MVP Local Demo',
                  style: TextStyle(color: Color(0xFF475569), fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
