import 'package:flutter/material.dart';

import '../../core/widgets/section_card.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پروفایل')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(
                children: [
                  Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      gradient: const LinearGradient(
                        colors: [Color(0xFF2563EB), Color(0xFF22C55E)],
                      ),
                    ),
                    child: const Icon(Icons.person_rounded, size: 40, color: Colors.white),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('کاربر آزمایشی', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                        SizedBox(height: 6),
                        Text('demo@journal.app', style: TextStyle(color: Color(0xFF94A3B8))),
                      ],
                    ),
                  ),
                  IconButton(onPressed: () {}, icon: const Icon(Icons.edit_rounded)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const SectionCard(
            title: 'اطلاعات حساب',
            child: Column(
              children: [
                _ProfileRow(title: 'بازار اصلی', value: 'کریپتو و فارکس'),
                _ProfileRow(title: 'واحد گزارش', value: 'دلار'),
                _ProfileRow(title: 'سرمایه اولیه', value: '10,000 دلار'),
                _ProfileRow(title: 'پلن فعلی', value: 'رایگان'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'تنظیمات',
            child: Column(
              children: [
                _ActionTile(icon: Icons.lock_rounded, title: 'تغییر رمز عبور', onTap: () {}),
                _ActionTile(icon: Icons.notifications_rounded, title: 'تنظیمات اعلان‌ها', onTap: () {}),
                _ActionTile(icon: Icons.palette_rounded, title: 'تغییر ظاهر اپ', onTap: () {}),
                _ActionTile(icon: Icons.logout_rounded, title: 'خروج از حساب', danger: true, onTap: () {}),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileRow extends StatelessWidget {
  const _ProfileRow({required this.title, required this.value});

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Expanded(child: Text(title, style: const TextStyle(color: Color(0xFF94A3B8)))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.icon, required this.title, required this.onTap, this.danger = false});

  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final color = danger ? const Color(0xFFEF4444) : const Color(0xFFCBD5E1);
    return ListTile(
      contentPadding: EdgeInsets.zero,
      onTap: onTap,
      leading: Icon(icon, color: color),
      title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w700)),
      trailing: const Icon(Icons.chevron_left_rounded),
    );
  }
}
