import 'package:flutter/material.dart';

import '../../data/models/support_ticket.dart';
import '../../data/repositories/trade_store.dart';
import 'ticket_form_screen.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);

    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(title: const Text('پشتیبانی')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('ارتباط با مدیر و پشتیبان‌ها', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 8),
                      const Text(
                        'برای مشکل فنی، پیشنهاد یا سوال درباره اپ، تیکت ارسال کن.',
                        style: TextStyle(color: Color(0xFF94A3B8), height: 1.7),
                      ),
                      const SizedBox(height: 16),
                      FilledButton.icon(
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(builder: (_) => const TicketFormScreen()));
                        },
                        icon: const Icon(Icons.add_comment_rounded),
                        label: const Text('ارسال تیکت جدید'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Text('تیکت‌های من', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              if (store.tickets.isEmpty)
                const Text('هنوز تیکتی ثبت نشده است.', style: TextStyle(color: Color(0xFF94A3B8)))
              else
                ...store.tickets.map((ticket) => _TicketCard(ticket: ticket)),
            ],
          ),
        );
      },
    );
  }
}

class _TicketCard extends StatelessWidget {
  const _TicketCard({required this.ticket});

  final SupportTicket ticket;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(ticket.subject, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F172A),
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: Text(ticketStatusLabel(ticket.status), style: const TextStyle(fontSize: 12)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(ticket.message, style: const TextStyle(color: Color(0xFF94A3B8), height: 1.6)),
          ],
        ),
      ),
    );
  }
}
