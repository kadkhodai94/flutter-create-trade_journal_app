import 'package:flutter/material.dart';

import '../../data/models/support_ticket.dart';
import '../../data/repositories/trade_store.dart';

class TicketFormScreen extends StatefulWidget {
  const TicketFormScreen({super.key});

  @override
  State<TicketFormScreen> createState() => _TicketFormScreenState();
}

class _TicketFormScreenState extends State<TicketFormScreen> {
  final _subject = TextEditingController();
  final _message = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _subject.dispose();
    _message.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    AppScope.of(context).addTicket(
      SupportTicket(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        subject: _subject.text.trim(),
        message: _message.text.trim(),
        status: TicketStatus.open,
        createdAt: DateTime.now(),
      ),
    );
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تیکت ثبت شد')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تیکت جدید')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            TextFormField(
              controller: _subject,
              validator: (value) => value == null || value.trim().isEmpty ? 'موضوع را وارد کن' : null,
              decoration: const InputDecoration(labelText: 'موضوع'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _message,
              minLines: 5,
              maxLines: 8,
              validator: (value) => value == null || value.trim().isEmpty ? 'متن پیام را وارد کن' : null,
              decoration: const InputDecoration(labelText: 'متن پیام'),
            ),
            const SizedBox(height: 18),
            OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.image_rounded),
              label: const Text('افزودن عکس در نسخه بعد'),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: _submit,
              icon: const Icon(Icons.send_rounded),
              label: const Text('ارسال تیکت'),
            ),
          ],
        ),
      ),
    );
  }
}
