import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/support_ticket.dart';
import '../models/trade.dart';

class AppScope extends InheritedNotifier<TradeStore> {
  const AppScope({
    super.key,
    required TradeStore store,
    required super.child,
  }) : super(notifier: store);

  static TradeStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope not found in context');
    return scope!.notifier!;
  }
}

class TradeStore extends ChangeNotifier {
  TradeStore({
    List<Trade>? trades,
    List<SupportTicket>? tickets,
    SharedPreferences? prefs,
  })  : _trades = trades ?? [],
        _tickets = tickets ?? [],
        _prefs = prefs;

  static const _tradesKey = 'trade_journal_trades_v2';
  static const _ticketsKey = 'trade_journal_tickets_v2';

  final SharedPreferences? _prefs;
  final List<Trade> _trades;
  final List<SupportTicket> _tickets;

  static Future<TradeStore> load() async {
    final prefs = await SharedPreferences.getInstance();
    final trades = _readTrades(prefs.getString(_tradesKey));
    final tickets = _readTickets(prefs.getString(_ticketsKey));

    if (trades == null && tickets == null) {
      return TradeStore.seeded(prefs: prefs);
    }

    return TradeStore(
      prefs: prefs,
      trades: trades ?? [],
      tickets: tickets ?? [],
    );
  }

  factory TradeStore.seeded({SharedPreferences? prefs}) {
    final now = DateTime.now();
    return TradeStore(
      prefs: prefs,
      trades: [
        Trade(
          id: '1',
          symbol: 'BTCUSDT',
          market: 'کریپتو',
          direction: TradeDirection.buy,
          entryDate: now.subtract(const Duration(days: 1)),
          exitDate: now.subtract(const Duration(hours: 18)),
          timeframe: '15m',
          entryPrice: 68400,
          stopLoss: 67950,
          targets: const [
            TradeTarget(title: 'تارگت 1', price: 69100, isHit: true),
            TradeTarget(title: 'تارگت 2', price: 69800, isHit: false),
          ],
          positionSize: 0.3,
          riskPercent: 1,
          strategy: 'پولبک به حمایت',
          reason: 'برگشت قیمت از محدوده حمایتی و تایید کندلی',
          emotion: 'آرام',
          status: TradeStatus.targetHit,
          exitPrice: 69100,
          profitLoss: 210,
          notes: 'ورود خوب بود ولی خروج کمی زود انجام شد.',
          images: const [
            TradeImageNote(type: 'شروع معامله', note: 'اسکرین‌شات چارت قبل از ورود'),
            TradeImageNote(type: 'خروج', note: 'قیمت بعد از تارگت اول برگشت'),
          ],
        ),
        Trade(
          id: '2',
          symbol: 'XAUUSD',
          market: 'فارکس',
          direction: TradeDirection.sell,
          entryDate: now.subtract(const Duration(days: 3)),
          exitDate: now.subtract(const Duration(days: 3, hours: -2)),
          timeframe: '1H',
          entryPrice: 2364,
          stopLoss: 2372,
          targets: const [
            TradeTarget(title: 'تارگت 1', price: 2356, isHit: false),
            TradeTarget(title: 'تارگت 2', price: 2348, isHit: false),
          ],
          positionSize: 1,
          riskPercent: 1.5,
          strategy: 'شکست ناموفق',
          reason: 'ورود بعد از شکست حمایت ولی بدون تایید کافی',
          emotion: 'عجله',
          status: TradeStatus.stopHit,
          exitPrice: 2372,
          profitLoss: -80,
          notes: 'ورود احساسی بود و خبر مهم هم نزدیک بود.',
          images: const [
            TradeImageNote(type: 'تحلیل', note: 'اسکرین‌شات محدوده شکست'),
          ],
        ),
        Trade(
          id: '3',
          symbol: 'EURUSD',
          market: 'فارکس',
          direction: TradeDirection.buy,
          entryDate: now.subtract(const Duration(days: 5)),
          exitDate: now.subtract(const Duration(days: 5, hours: -4)),
          timeframe: '30m',
          entryPrice: 1.0810,
          stopLoss: 1.0785,
          targets: const [
            TradeTarget(title: 'تارگت 1', price: 1.0840, isHit: true),
            TradeTarget(title: 'تارگت 2', price: 1.0870, isHit: true),
          ],
          positionSize: 10000,
          riskPercent: 1,
          strategy: 'روند صعودی',
          reason: 'هماهنگی روند تایم بالا و پولبک',
          emotion: 'متمرکز',
          status: TradeStatus.targetHit,
          exitPrice: 1.0870,
          profitLoss: 60,
          notes: 'معامله کاملاً طبق پلن انجام شد.',
          images: const [],
        ),
      ],
      tickets: [
        SupportTicket(
          id: 't1',
          subject: 'خوش آمدی به نسخه آزمایشی',
          message: 'از این نسخه به بعد معاملات و تیکت‌ها روی گوشی ذخیره می‌شوند.',
          status: TicketStatus.answered,
          createdAt: now.subtract(const Duration(days: 1)),
        ),
      ],
    );
  }

  List<Trade> get trades => List.unmodifiable(_trades);
  List<SupportTicket> get tickets => List.unmodifiable(_tickets);

  void addTrade(Trade trade) {
    _trades.insert(0, trade);
    _save();
    notifyListeners();
  }

  void updateTrade(Trade trade) {
    final index = _trades.indexWhere((item) => item.id == trade.id);
    if (index == -1) return;
    _trades[index] = trade;
    _save();
    notifyListeners();
  }

  void deleteTrade(String tradeId) {
    _trades.removeWhere((trade) => trade.id == tradeId);
    _save();
    notifyListeners();
  }

  void addTicket(SupportTicket ticket) {
    _tickets.insert(0, ticket);
    _save();
    notifyListeners();
  }

  List<Trade> tradesForRange(ReportRange range) {
    final now = DateTime.now();
    DateTime? from;
    switch (range) {
      case ReportRange.week:
        from = now.subtract(const Duration(days: 7));
        break;
      case ReportRange.month:
        from = DateTime(now.year, now.month, 1);
        break;
      case ReportRange.year:
        from = DateTime(now.year, 1, 1);
        break;
      case ReportRange.all:
        from = null;
        break;
    }
    if (from == null) return trades;
    return _trades.where((trade) => trade.entryDate.isAfter(from!)).toList();
  }

  ReportStats stats(ReportRange range) {
    final filtered = tradesForRange(range);
    final closed = filtered.where((trade) => trade.isClosed).toList()
      ..sort((a, b) => a.entryDate.compareTo(b.entryDate));
    final open = filtered.where((trade) => trade.status == TradeStatus.open).length;
    final wins = closed.where((trade) => trade.isWin).length;
    final losses = closed.where((trade) => trade.isLoss).length;
    final breakEvens = closed.where((trade) => trade.profitLoss == 0).length;
    final net = closed.fold<double>(0, (sum, trade) => sum + trade.profitLoss);
    final grossProfit = closed.where((trade) => trade.isWin).fold<double>(0, (sum, trade) => sum + trade.profitLoss);
    final grossLoss = closed.where((trade) => trade.isLoss).fold<double>(0, (sum, trade) => sum + trade.profitLoss.abs());
    final averageWin = wins == 0 ? 0.0 : grossProfit / wins;
    final averageLoss = losses == 0 ? 0.0 : grossLoss / losses;
    final expectancy = closed.isEmpty ? 0.0 : net / closed.length;
    final profitFactor = grossLoss == 0 ? (grossProfit > 0 ? grossProfit : 0.0) : grossProfit / grossLoss;
    final payoffRatio = averageLoss == 0 ? 0.0 : averageWin / averageLoss;

    final target1Base = closed.where((trade) => trade.targets.isNotEmpty).length;
    final target2Base = closed.where((trade) => trade.targets.length > 1).length;
    final target1Hits = closed.where((trade) => trade.targets.isNotEmpty && trade.targets.first.isHit).length;
    final target2Hits = closed.where((trade) => trade.targets.length > 1 && trade.targets[1].isHit).length;

    final rrTrades = filtered.where((trade) => trade.bestRiskReward > 0).toList();
    final averageRiskReward = rrTrades.isEmpty
        ? 0.0
        : rrTrades.fold<double>(0, (sum, trade) => sum + trade.bestRiskReward) / rrTrades.length;
    final realizedRRTrades = closed.where((trade) => trade.plannedRiskAmount > 0).toList();
    final averageRealizedRiskReward = realizedRRTrades.isEmpty
        ? 0.0
        : realizedRRTrades.fold<double>(0, (sum, trade) => sum + trade.actualRiskReward) / realizedRRTrades.length;

    Trade? bestTrade;
    Trade? worstTrade;
    for (final trade in closed) {
      if (bestTrade == null || trade.profitLoss > bestTrade.profitLoss) bestTrade = trade;
      if (worstTrade == null || trade.profitLoss < worstTrade.profitLoss) worstTrade = trade;
    }

    var currentWinStreak = 0;
    var currentLossStreak = 0;
    var longestWinStreak = 0;
    var longestLossStreak = 0;
    for (final trade in closed) {
      if (trade.isWin) {
        currentWinStreak++;
        currentLossStreak = 0;
      } else if (trade.isLoss) {
        currentLossStreak++;
        currentWinStreak = 0;
      } else {
        currentWinStreak = 0;
        currentLossStreak = 0;
      }
      if (currentWinStreak > longestWinStreak) longestWinStreak = currentWinStreak;
      if (currentLossStreak > longestLossStreak) longestLossStreak = currentLossStreak;
    }

    final bestSymbol = _bestPerformance(closed, (trade) => trade.symbol, highest: true);
    final worstSymbol = _bestPerformance(closed, (trade) => trade.symbol, highest: false);
    final bestStrategy = _bestPerformance(closed, (trade) => trade.strategy, highest: true);
    final worstStrategy = _bestPerformance(closed, (trade) => trade.strategy, highest: false);
    final bestTimeframe = _bestPerformance(closed, (trade) => trade.timeframe, highest: true);
    final worstTimeframe = _bestPerformance(closed, (trade) => trade.timeframe, highest: false);
    final bestEmotion = _bestPerformance(closed, (trade) => trade.emotion, highest: true);
    final worstEmotion = _bestPerformance(closed, (trade) => trade.emotion, highest: false);

    final plannedTrades = filtered.where((trade) => trade.reason != 'ثبت نشده' && trade.strategy != 'ثبت نشده').length;
    final planCompletionRate = filtered.isEmpty ? 0.0 : (plannedTrades / filtered.length) * 100;

    final insights = _buildInsights(
      closed: closed,
      winRate: closed.isEmpty ? 0 : (wins / closed.length) * 100,
      net: net,
      profitFactor: profitFactor,
      expectancy: expectancy,
      averageRiskReward: averageRiskReward,
      averageRealizedRiskReward: averageRealizedRiskReward,
      bestSymbol: bestSymbol,
      worstSymbol: worstSymbol,
      worstEmotion: worstEmotion,
      longestLossStreak: longestLossStreak,
      planCompletionRate: planCompletionRate,
    );

    return ReportStats(
      total: filtered.length,
      open: open,
      closed: closed.length,
      wins: wins,
      losses: losses,
      breakEvens: breakEvens,
      netProfitLoss: net,
      grossProfit: grossProfit,
      grossLoss: grossLoss,
      averageWin: averageWin,
      averageLoss: averageLoss,
      expectancy: expectancy,
      profitFactor: profitFactor,
      payoffRatio: payoffRatio,
      target1Hits: target1Hits,
      target2Hits: target2Hits,
      target1Base: target1Base,
      target2Base: target2Base,
      averageRiskReward: averageRiskReward,
      averageRealizedRiskReward: averageRealizedRiskReward,
      bestTrade: bestTrade,
      worstTrade: worstTrade,
      longestWinStreak: longestWinStreak,
      longestLossStreak: longestLossStreak,
      bestSymbol: bestSymbol,
      worstSymbol: worstSymbol,
      bestStrategy: bestStrategy,
      worstStrategy: worstStrategy,
      bestTimeframe: bestTimeframe,
      worstTimeframe: worstTimeframe,
      bestEmotion: bestEmotion,
      worstEmotion: worstEmotion,
      planCompletionRate: planCompletionRate,
      insights: insights,
    );
  }

  PerformanceSummary? _bestPerformance(
    List<Trade> trades,
    String Function(Trade trade) selector, {
    required bool highest,
  }) {
    final map = <String, List<Trade>>{};
    for (final trade in trades) {
      final label = selector(trade).trim().isEmpty ? 'ثبت نشده' : selector(trade).trim();
      map.putIfAbsent(label, () => []).add(trade);
    }
    if (map.isEmpty) return null;

    final summaries = map.entries.map((entry) {
      final items = entry.value;
      final net = items.fold<double>(0, (sum, trade) => sum + trade.profitLoss);
      final wins = items.where((trade) => trade.isWin).length;
      return PerformanceSummary(
        label: entry.key,
        netProfitLoss: net,
        count: items.length,
        winRate: items.isEmpty ? 0 : (wins / items.length) * 100,
      );
    }).toList();

    summaries.sort((a, b) => highest
        ? b.netProfitLoss.compareTo(a.netProfitLoss)
        : a.netProfitLoss.compareTo(b.netProfitLoss));
    return summaries.first;
  }

  List<String> _buildInsights({
    required List<Trade> closed,
    required double winRate,
    required double net,
    required double profitFactor,
    required double expectancy,
    required double averageRiskReward,
    required double averageRealizedRiskReward,
    required PerformanceSummary? bestSymbol,
    required PerformanceSummary? worstSymbol,
    required PerformanceSummary? worstEmotion,
    required int longestLossStreak,
    required double planCompletionRate,
  }) {
    if (closed.isEmpty) {
      return const [
        'برای تحلیل خودکار، حداقل یک معامله بسته‌شده لازم است.',
        'بعد از وارد کردن قیمت خروج، سود/ضرر، تارگت‌های خورده و R:R واقعی خودکار محاسبه می‌شود.',
      ];
    }

    final items = <String>[];
    items.add(net >= 0
        ? 'عملکرد این بازه مثبت است؛ سود خالص ${net.toStringAsFixed(1)} ثبت شده.'
        : 'عملکرد این بازه منفی است؛ ضرر خالص ${net.abs().toStringAsFixed(1)} ثبت شده.');

    items.add(winRate >= 50
        ? 'Win Rate بالای ۵۰٪ است؛ کیفیت انتخاب معاملات قابل قبول است.'
        : 'Win Rate زیر ۵۰٪ است؛ بهتر است فیلتر ورود و تاییدیه‌ها سخت‌گیرانه‌تر شوند.');

    if (profitFactor > 0) {
      items.add(profitFactor >= 1.5
          ? 'Profit Factor مناسب است؛ مجموع سودها نسبت به ضررها برتری دارد.'
          : 'Profit Factor پایین است؛ باید یا میانگین سود بیشتر شود یا ضررهای بزرگ کنترل شوند.');
    }

    items.add(expectancy >= 0
        ? 'Expectancy مثبت است؛ میانگین خروجی هر معامله به نفع سیستم است.'
        : 'Expectancy منفی است؛ سیستم فعلی در هر معامله به‌طور میانگین زیان‌ده است.');

    if (averageRiskReward > 0) {
      items.add(averageRiskReward >= 2
          ? 'میانگین R:R برنامه‌ریزی‌شده خوب است و تارگت‌ها منطقی انتخاب شده‌اند.'
          : 'میانگین R:R برنامه‌ریزی‌شده پایین است؛ بهتر است معاملات زیر 1:2 کمتر شوند.');
    }

    if (averageRealizedRiskReward != 0) {
      items.add(averageRealizedRiskReward >= 1
          ? 'R واقعی معاملات مثبت است؛ خروج‌ها نسبت به ریسک اولیه قابل قبول‌اند.'
          : 'R واقعی پایین است؛ احتمالاً خروج زودهنگام یا ضررهای بزرگ روی نتیجه اثر گذاشته‌اند.');
    }

    if (bestSymbol != null) {
      items.add('بهترین نماد این بازه ${bestSymbol.label} با نتیجه ${bestSymbol.netProfitLoss.toStringAsFixed(1)} است.');
    }
    if (worstSymbol != null && worstSymbol.netProfitLoss < 0) {
      items.add('ضعیف‌ترین نماد ${worstSymbol.label} بوده؛ بهتر است معاملات این نماد جدا بررسی شود.');
    }
    if (worstEmotion != null && worstEmotion.netProfitLoss < 0) {
      items.add('احساس «${worstEmotion.label}» بیشترین اثر منفی را داشته؛ این مورد را قبل از ورود کنترل کن.');
    }
    if (longestLossStreak >= 3) {
      items.add('بیشترین ضرر پشت‌سرهم $longestLossStreak معامله بوده؛ بعد از دو ضرر پشت‌سرهم توقف اجباری مفید است.');
    }
    if (planCompletionRate < 70) {
      items.add('بخشی از معاملات بدون استراتژی یا دلیل ورود ثبت شده‌اند؛ برای تحلیل دقیق‌تر این دو فیلد را کامل کن.');
    }

    return items.take(8).toList();
  }

  Future<void> _save() async {
    final prefs = _prefs;
    if (prefs == null) return;
    await prefs.setString(_tradesKey, jsonEncode(_trades.map((trade) => trade.toJson()).toList()));
    await prefs.setString(_ticketsKey, jsonEncode(_tickets.map((ticket) => ticket.toJson()).toList()));
  }

  static List<Trade>? _readTrades(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    try {
      final decoded = jsonDecode(raw) as List;
      return decoded
          .whereType<Map>()
          .map((item) => Trade.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return null;
    }
  }

  static List<SupportTicket>? _readTickets(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    try {
      final decoded = jsonDecode(raw) as List;
      return decoded
          .whereType<Map>()
          .map((item) => SupportTicket.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return null;
    }
  }
}

class PerformanceSummary {
  const PerformanceSummary({
    required this.label,
    required this.netProfitLoss,
    required this.count,
    required this.winRate,
  });

  final String label;
  final double netProfitLoss;
  final int count;
  final double winRate;
}

class ReportStats {
  const ReportStats({
    required this.total,
    required this.open,
    required this.closed,
    required this.wins,
    required this.losses,
    required this.breakEvens,
    required this.netProfitLoss,
    required this.grossProfit,
    required this.grossLoss,
    required this.averageWin,
    required this.averageLoss,
    required this.expectancy,
    required this.profitFactor,
    required this.payoffRatio,
    required this.target1Hits,
    required this.target2Hits,
    required this.target1Base,
    required this.target2Base,
    required this.averageRiskReward,
    required this.averageRealizedRiskReward,
    required this.bestTrade,
    required this.worstTrade,
    required this.longestWinStreak,
    required this.longestLossStreak,
    required this.bestSymbol,
    required this.worstSymbol,
    required this.bestStrategy,
    required this.worstStrategy,
    required this.bestTimeframe,
    required this.worstTimeframe,
    required this.bestEmotion,
    required this.worstEmotion,
    required this.planCompletionRate,
    required this.insights,
  });

  final int total;
  final int open;
  final int closed;
  final int wins;
  final int losses;
  final int breakEvens;
  final double netProfitLoss;
  final double grossProfit;
  final double grossLoss;
  final double averageWin;
  final double averageLoss;
  final double expectancy;
  final double profitFactor;
  final double payoffRatio;
  final int target1Hits;
  final int target2Hits;
  final int target1Base;
  final int target2Base;
  final double averageRiskReward;
  final double averageRealizedRiskReward;
  final Trade? bestTrade;
  final Trade? worstTrade;
  final int longestWinStreak;
  final int longestLossStreak;
  final PerformanceSummary? bestSymbol;
  final PerformanceSummary? worstSymbol;
  final PerformanceSummary? bestStrategy;
  final PerformanceSummary? worstStrategy;
  final PerformanceSummary? bestTimeframe;
  final PerformanceSummary? worstTimeframe;
  final PerformanceSummary? bestEmotion;
  final PerformanceSummary? worstEmotion;
  final double planCompletionRate;
  final List<String> insights;

  double get winRate => closed == 0 ? 0 : (wins / closed) * 100;
  double get lossRate => closed == 0 ? 0 : (losses / closed) * 100;
  double get breakEvenRate => closed == 0 ? 0 : (breakEvens / closed) * 100;
  double get target1Rate => target1Base == 0 ? 0 : (target1Hits / target1Base) * 100;
  double get target2Rate => target2Base == 0 ? 0 : (target2Hits / target2Base) * 100;
  double get averageProfitLoss => closed == 0 ? 0 : netProfitLoss / closed;
}
