enum TradeDirection { buy, sell }
enum TradeStatus { open, closed, targetHit, stopHit, breakEven }
enum ReportRange { week, month, year, all }

class TradeTarget {
  const TradeTarget({
    required this.title,
    required this.price,
    this.isHit = false,
  });

  final String title;
  final double price;
  final bool isHit;

  TradeTarget copyWith({
    String? title,
    double? price,
    bool? isHit,
  }) {
    return TradeTarget(
      title: title ?? this.title,
      price: price ?? this.price,
      isHit: isHit ?? this.isHit,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'price': price,
      'isHit': isHit,
    };
  }

  factory TradeTarget.fromJson(Map<String, dynamic> json) {
    return TradeTarget(
      title: json['title'] as String? ?? 'تارگت',
      price: (json['price'] as num?)?.toDouble() ?? 0,
      isHit: json['isHit'] as bool? ?? false,
    );
  }
}

class TradeImageNote {
  const TradeImageNote({
    required this.type,
    required this.note,
    this.path,
  });

  final String type;
  final String note;
  final String? path;

  Map<String, dynamic> toJson() {
    return {
      'type': type,
      'note': note,
      'path': path,
    };
  }

  factory TradeImageNote.fromJson(Map<String, dynamic> json) {
    return TradeImageNote(
      type: json['type'] as String? ?? 'عکس معامله',
      note: json['note'] as String? ?? '',
      path: json['path'] as String?,
    );
  }
}

class Trade {
  const Trade({
    required this.id,
    required this.symbol,
    required this.market,
    required this.direction,
    required this.entryDate,
    required this.timeframe,
    required this.entryPrice,
    required this.stopLoss,
    required this.targets,
    required this.positionSize,
    required this.riskPercent,
    required this.strategy,
    required this.reason,
    required this.emotion,
    required this.status,
    required this.images,
    this.exitDate,
    this.exitPrice,
    this.profitLoss = 0,
    this.notes = '',
  });

  final String id;
  final String symbol;
  final String market;
  final TradeDirection direction;
  final DateTime entryDate;
  final DateTime? exitDate;
  final String timeframe;
  final double entryPrice;
  final double stopLoss;
  final List<TradeTarget> targets;
  final double positionSize;
  final double riskPercent;
  final String strategy;
  final String reason;
  final String emotion;
  final TradeStatus status;
  final double? exitPrice;
  final double profitLoss;
  final String notes;
  final List<TradeImageNote> images;

  bool get isWin => profitLoss > 0;
  bool get isLoss => profitLoss < 0;
  bool get isClosed => status != TradeStatus.open;

  double get profitLossPercent {
    if (entryPrice == 0 || positionSize == 0) return 0;
    final base = entryPrice * positionSize;
    if (base == 0) return 0;
    return (profitLoss / base) * 100;
  }

  double get riskUnitSize => positionSize <= 0 ? 1 : positionSize;

  double get plannedRiskAmount => riskDistance * riskUnitSize;

  double get actualRiskReward {
    final risk = plannedRiskAmount;
    if (!isClosed || risk <= 0) return 0;
    return profitLoss / risk;
  }

  String get actualRiskRewardLabel {
    if (!isClosed || plannedRiskAmount <= 0) return '-';
    final value = actualRiskReward;
    if (value == 0) return '0R';
    return '${value.toStringAsFixed(2)}R';
  }

  double computedProfitLossForExit(double? exit) {
    if (exit == null || entryPrice == 0) return 0;
    final distance = direction == TradeDirection.buy ? exit - entryPrice : entryPrice - exit;
    return distance * riskUnitSize;
  }

  bool isTargetHitByExit(TradeTarget target, double? exit) {
    if (exit == null || target.price == 0) return target.isHit;
    return direction == TradeDirection.buy ? exit >= target.price : exit <= target.price;
  }

  TradeStatus automaticStatusForExit(double? exit) {
    if (exit == null) return TradeStatus.open;
    final pnl = computedProfitLossForExit(exit);
    if (pnl == 0) return TradeStatus.breakEven;
    final stopped = direction == TradeDirection.buy ? exit <= stopLoss : exit >= stopLoss;
    if (stopped && stopLoss > 0) return TradeStatus.stopHit;
    final hasHitTarget = targets.any((target) => isTargetHitByExit(target, exit));
    if (hasHitTarget && pnl > 0) return TradeStatus.targetHit;
    return TradeStatus.closed;
  }

  double get riskDistance {
    if (entryPrice == 0 || stopLoss == 0) return 0;
    return (entryPrice - stopLoss).abs();
  }

  double rewardDistanceForTarget(TradeTarget target) {
    if (entryPrice == 0 || target.price == 0) return 0;
    final reward = direction == TradeDirection.buy
        ? target.price - entryPrice
        : entryPrice - target.price;
    return reward <= 0 ? 0 : reward;
  }

  double riskRewardForTarget(TradeTarget target) {
    final risk = riskDistance;
    final reward = rewardDistanceForTarget(target);
    if (risk <= 0 || reward <= 0) return 0;
    return reward / risk;
  }

  String riskRewardLabelForTarget(TradeTarget target) {
    final ratio = riskRewardForTarget(target);
    if (ratio <= 0) return '-';
    return '1:${ratio.toStringAsFixed(2)}';
  }

  double get bestRiskReward {
    if (targets.isEmpty) return 0;
    double best = 0;
    for (final target in targets) {
      final ratio = riskRewardForTarget(target);
      if (ratio > best) best = ratio;
    }
    return best;
  }

  String get bestRiskRewardLabel {
    final best = bestRiskReward;
    if (best <= 0) return '-';
    return '1:${best.toStringAsFixed(2)}';
  }

  Trade copyWith({
    String? id,
    String? symbol,
    String? market,
    TradeDirection? direction,
    DateTime? entryDate,
    DateTime? exitDate,
    bool clearExitDate = false,
    String? timeframe,
    double? entryPrice,
    double? stopLoss,
    List<TradeTarget>? targets,
    double? positionSize,
    double? riskPercent,
    String? strategy,
    String? reason,
    String? emotion,
    TradeStatus? status,
    double? exitPrice,
    bool clearExitPrice = false,
    double? profitLoss,
    String? notes,
    List<TradeImageNote>? images,
  }) {
    return Trade(
      id: id ?? this.id,
      symbol: symbol ?? this.symbol,
      market: market ?? this.market,
      direction: direction ?? this.direction,
      entryDate: entryDate ?? this.entryDate,
      exitDate: clearExitDate ? null : exitDate ?? this.exitDate,
      timeframe: timeframe ?? this.timeframe,
      entryPrice: entryPrice ?? this.entryPrice,
      stopLoss: stopLoss ?? this.stopLoss,
      targets: targets ?? this.targets,
      positionSize: positionSize ?? this.positionSize,
      riskPercent: riskPercent ?? this.riskPercent,
      strategy: strategy ?? this.strategy,
      reason: reason ?? this.reason,
      emotion: emotion ?? this.emotion,
      status: status ?? this.status,
      exitPrice: clearExitPrice ? null : exitPrice ?? this.exitPrice,
      profitLoss: profitLoss ?? this.profitLoss,
      notes: notes ?? this.notes,
      images: images ?? this.images,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'symbol': symbol,
      'market': market,
      'direction': direction.name,
      'entryDate': entryDate.toIso8601String(),
      'exitDate': exitDate?.toIso8601String(),
      'timeframe': timeframe,
      'entryPrice': entryPrice,
      'stopLoss': stopLoss,
      'targets': targets.map((target) => target.toJson()).toList(),
      'positionSize': positionSize,
      'riskPercent': riskPercent,
      'strategy': strategy,
      'reason': reason,
      'emotion': emotion,
      'status': status.name,
      'exitPrice': exitPrice,
      'profitLoss': profitLoss,
      'notes': notes,
      'images': images.map((image) => image.toJson()).toList(),
    };
  }

  factory Trade.fromJson(Map<String, dynamic> json) {
    return Trade(
      id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
      symbol: json['symbol'] as String? ?? '-',
      market: json['market'] as String? ?? 'ثبت نشده',
      direction: _enumFromName(TradeDirection.values, json['direction'] as String?, TradeDirection.buy),
      entryDate: DateTime.tryParse(json['entryDate'] as String? ?? '') ?? DateTime.now(),
      exitDate: DateTime.tryParse(json['exitDate'] as String? ?? ''),
      timeframe: json['timeframe'] as String? ?? '15m',
      entryPrice: (json['entryPrice'] as num?)?.toDouble() ?? 0,
      stopLoss: (json['stopLoss'] as num?)?.toDouble() ?? 0,
      targets: ((json['targets'] as List?) ?? const [])
          .whereType<Map>()
          .map((item) => TradeTarget.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
      positionSize: (json['positionSize'] as num?)?.toDouble() ?? 0,
      riskPercent: (json['riskPercent'] as num?)?.toDouble() ?? 0,
      strategy: json['strategy'] as String? ?? 'ثبت نشده',
      reason: json['reason'] as String? ?? 'ثبت نشده',
      emotion: json['emotion'] as String? ?? 'ثبت نشده',
      status: _enumFromName(TradeStatus.values, json['status'] as String?, TradeStatus.open),
      exitPrice: (json['exitPrice'] as num?)?.toDouble(),
      profitLoss: (json['profitLoss'] as num?)?.toDouble() ?? 0,
      notes: json['notes'] as String? ?? '',
      images: ((json['images'] as List?) ?? const [])
          .whereType<Map>()
          .map((item) => TradeImageNote.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
    );
  }
}

T _enumFromName<T extends Enum>(List<T> values, String? name, T fallback) {
  for (final value in values) {
    if (value.name == name) return value;
  }
  return fallback;
}

String directionLabel(TradeDirection value) {
  switch (value) {
    case TradeDirection.buy:
      return 'خرید';
    case TradeDirection.sell:
      return 'فروش';
  }
}

String statusLabel(TradeStatus value) {
  switch (value) {
    case TradeStatus.open:
      return 'باز';
    case TradeStatus.closed:
      return 'بسته‌شده';
    case TradeStatus.targetHit:
      return 'تارگت خورده';
    case TradeStatus.stopHit:
      return 'استاپ خورده';
    case TradeStatus.breakEven:
      return 'سربه‌سر';
  }
}
