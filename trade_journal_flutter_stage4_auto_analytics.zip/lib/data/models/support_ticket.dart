enum TicketStatus { open, pending, answered, closed }

class SupportTicket {
  const SupportTicket({
    required this.id,
    required this.subject,
    required this.message,
    required this.status,
    required this.createdAt,
  });

  final String id;
  final String subject;
  final String message;
  final TicketStatus status;
  final DateTime createdAt;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'subject': subject,
      'message': message,
      'status': status.name,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory SupportTicket.fromJson(Map<String, dynamic> json) {
    return SupportTicket(
      id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
      subject: json['subject'] as String? ?? 'بدون موضوع',
      message: json['message'] as String? ?? '',
      status: _statusFromName(json['status'] as String?),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
    );
  }
}

TicketStatus _statusFromName(String? name) {
  for (final value in TicketStatus.values) {
    if (value.name == name) return value;
  }
  return TicketStatus.open;
}

String ticketStatusLabel(TicketStatus status) {
  switch (status) {
    case TicketStatus.open:
      return 'باز';
    case TicketStatus.pending:
      return 'در حال بررسی';
    case TicketStatus.answered:
      return 'پاسخ داده‌شده';
    case TicketStatus.closed:
      return 'بسته‌شده';
  }
}
