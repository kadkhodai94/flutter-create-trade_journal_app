import 'package:flutter/material.dart';

import 'app.dart';
import 'data/repositories/trade_store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await TradeStore.load();
  runApp(
    AppScope(
      store: store,
      child: const TradeJournalApp(),
    ),
  );
}
