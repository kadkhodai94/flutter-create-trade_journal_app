import 'package:flutter/material.dart';

import 'app.dart';
import 'data/repositories/trade_store.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    AppScope(
      store: TradeStore.seeded(),
      child: const TradeJournalApp(),
    ),
  );
}
