import 'package:flutter/material.dart';

import '../../data/models/trade.dart';
import '../../data/repositories/trade_store.dart';
import 'trade_details_screen.dart';

class TradeListScreen extends StatefulWidget {
  const TradeListScreen({super.key});

  @override
  State<TradeListScreen> createState() => _TradeListScreenState();
}

class _TradeListScreenState extends State<TradeListScreen> {
  String _query = '';
  String _statusFilter = 'همه';

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);

    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final trades = store.trades.where((trade) {
          final matchesQuery = trade.symbol.toLowerCase().contains(_query.toLowerCase()) ||
              trade.market.toLowerCase().contains(_query.toLowerCase()) ||
              trade.strategy.toLowerCase().contains(_query.toLowerCase());
          final matchesStatus = _statusFilter == 'همه' || statusLabel(trade.status) == _statusFilter;
          return matchesQuery && matchesStatus;
        }).toList();

        return Scaffold(
          appBar: AppBar(title: const Text('معاملات')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
            children: [
              TextField(
                onChanged: (value) => setState(() => _query = value),
                decoration: const InputDecoration(
                  labelText: 'جستجو بر اساس نماد، بازار یا استراتژی',
                  prefixIcon: Icon(Icons.search_rounded),
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _statusFilter,
                decoration: const InputDecoration(labelText: 'فیلتر وضعیت'),
                items: const [
                  DropdownMenuItem(value: 'همه', child: Text('همه')),
                  DropdownMenuItem(value: 'باز', child: Text('باز')),
                  DropdownMenuItem(value: 'بسته‌شده', child: Text('بسته‌شده')),
                  DropdownMenuItem(value: 'تارگت خورده', child: Text('تارگت خورده')),
                  DropdownMenuItem(value: 'استاپ خورده', child: Text('استاپ خورده')),
                  DropdownMenuItem(value: 'سربه‌سر', child: Text('سربه‌سر')),
                ],
                onChanged: (value) => setState(() => _statusFilter = value ?? 'همه'),
              ),
              const SizedBox(height: 18),
              if (trades.isEmpty)
                const _EmptyTradeList()
              else
                ...trades.map((trade) => _TradeCard(trade: trade)),
            ],
          ),
        );
      },
    );
  }
}

class _EmptyTradeList extends StatelessWidget {
  const _EmptyTradeList();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: const Color(0xFF111827),
        borderRadius: BorderRadius.circular(24),
      ),
      child: const Column(
        children: [
          Icon(Icons.inbox_rounded, size: 44, color: Color(0xFF64748B)),
          SizedBox(height: 12),
          Text('معامله‌ای پیدا نشد'),
        ],
      ),
    );
  }
}

class _TradeCard extends StatelessWidget {
  const _TradeCard({required this.trade});

  final Trade trade;

  @override
  Widget build(BuildContext context) {
    final isPositive = trade.profitLoss >= 0;
    final pnlColor = isPositive ? const Color(0xFF22C55E) : const Color(0xFFEF4444);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => TradeDetailsScreen(trade: trade)),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      trade.symbol,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: pnlColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: Text(
                      '${trade.profitLoss.toStringAsFixed(1)} دلار',
                      style: TextStyle(color: pnlColor, fontWeight: FontWeight.w800),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                '${trade.market} • ${directionLabel(trade.direction)} • ${trade.timeframe} • ${statusLabel(trade.status)}',
                style: const TextStyle(color: Color(0xFF94A3B8)),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _Chip(text: 'ورود: ${trade.entryPrice}'),
                  _Chip(text: 'استاپ: ${trade.stopLoss}'),
                  _Chip(text: 'استراتژی: ${trade.strategy}'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Text(text, style: const TextStyle(fontSize: 12, color: Color(0xFFCBD5E1))),
    );
  }
}
