import 'package:flutter/material.dart';

import '../../core/widgets/section_card.dart';
import '../../data/models/trade.dart';

class TradeDetailsScreen extends StatelessWidget {
  const TradeDetailsScreen({super.key, required this.trade});

  final Trade trade;

  @override
  Widget build(BuildContext context) {
    final pnlColor = trade.profitLoss >= 0 ? const Color(0xFF22C55E) : const Color(0xFFEF4444);

    return Scaffold(
      appBar: AppBar(
        title: Text(trade.symbol),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.edit_rounded)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          trade.symbol,
                          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
                        ),
                      ),
                      Text(
                        '${trade.profitLoss.toStringAsFixed(1)} دلار',
                        style: TextStyle(color: pnlColor, fontSize: 22, fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '${trade.market} • ${directionLabel(trade.direction)} • ${trade.timeframe} • ${statusLabel(trade.status)}',
                    style: const TextStyle(color: Color(0xFF94A3B8)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'قیمت‌ها',
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _InfoPill(label: 'ورود', value: '${trade.entryPrice}'),
                _InfoPill(label: 'خروج', value: trade.exitPrice?.toString() ?? '-'),
                _InfoPill(label: 'حد ضرر', value: '${trade.stopLoss}'),
                _InfoPill(label: 'حجم', value: '${trade.positionSize}'),
                _InfoPill(label: 'ریسک', value: '${trade.riskPercent}%'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'تارگت‌ها',
            child: Column(
              children: trade.targets.map((target) {
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    target.isHit ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                    color: target.isHit ? const Color(0xFF22C55E) : const Color(0xFF64748B),
                  ),
                  title: Text(target.title),
                  trailing: Text('${target.price}', style: const TextStyle(fontWeight: FontWeight.w800)),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'تحلیل معامله',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _TextBlock(title: 'استراتژی', value: trade.strategy),
                _TextBlock(title: 'دلیل ورود', value: trade.reason),
                _TextBlock(title: 'احساس قبل از ورود', value: trade.emotion),
                if (trade.notes.isNotEmpty) _TextBlock(title: 'یادداشت نهایی', value: trade.notes),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'عکس‌ها و مستندات',
            subtitle: 'فعلاً به‌صورت یادداشت تصویری در نسخه MVP ذخیره شده است.',
            child: trade.images.isEmpty
                ? const Text('هنوز تصویری ثبت نشده است.', style: TextStyle(color: Color(0xFF94A3B8)))
                : Column(
                    children: trade.images.map((image) {
                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0F172A),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: const Color(0xFF263247)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.image_rounded, color: Color(0xFF3B82F6)),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(image.type, style: const TextStyle(fontWeight: FontWeight.w800)),
                                  const SizedBox(height: 4),
                                  Text(image.note, style: const TextStyle(color: Color(0xFF94A3B8))),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
          ),
        ],
      ),
    );
  }
}

class _InfoPill extends StatelessWidget {
  const _InfoPill({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 145,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF263247)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _TextBlock extends StatelessWidget {
  const _TextBlock({required this.title, required this.value});

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
          const SizedBox(height: 5),
          Text(value, style: const TextStyle(height: 1.7)),
        ],
      ),
    );
  }
}
