import 'package:flutter/material.dart';

import '../../data/models/trade.dart';
import '../../data/repositories/trade_store.dart';

class TradeFormScreen extends StatefulWidget {
  const TradeFormScreen({super.key});

  @override
  State<TradeFormScreen> createState() => _TradeFormScreenState();
}

class _TradeFormScreenState extends State<TradeFormScreen> {
  final _formKey = GlobalKey<FormState>();

  final _symbol = TextEditingController(text: 'BTCUSDT');
  final _entryPrice = TextEditingController();
  final _stopLoss = TextEditingController();
  final _target1 = TextEditingController();
  final _target2 = TextEditingController();
  final _positionSize = TextEditingController();
  final _riskPercent = TextEditingController(text: '1');
  final _strategy = TextEditingController();
  final _reason = TextEditingController();
  final _notes = TextEditingController();
  final _imageNote = TextEditingController();

  String _market = 'کریپتو';
  String _timeframe = '15m';
  String _emotion = 'آرام';
  TradeDirection _direction = TradeDirection.buy;
  TradeStatus _status = TradeStatus.open;
  final List<TextEditingController> _extraTargets = [];

  @override
  void dispose() {
    _symbol.dispose();
    _entryPrice.dispose();
    _stopLoss.dispose();
    _target1.dispose();
    _target2.dispose();
    _positionSize.dispose();
    _riskPercent.dispose();
    _strategy.dispose();
    _reason.dispose();
    _notes.dispose();
    _imageNote.dispose();
    for (final controller in _extraTargets) {
      controller.dispose();
    }
    super.dispose();
  }

  String? _required(String? value) {
    if (value == null || value.trim().isEmpty) return 'این فیلد لازم است';
    return null;
  }

  double _doubleValue(TextEditingController controller) {
    return double.tryParse(controller.text.trim().replaceAll(',', '.')) ?? 0;
  }

  void _addTargetField() {
    setState(() => _extraTargets.add(TextEditingController()));
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final store = AppScope.of(context);
    final targets = <TradeTarget>[
      TradeTarget(title: 'تارگت 1', price: _doubleValue(_target1)),
      TradeTarget(title: 'تارگت 2', price: _doubleValue(_target2)),
      for (int i = 0; i < _extraTargets.length; i++)
        TradeTarget(title: 'تارگت ${i + 3}', price: _doubleValue(_extraTargets[i])),
    ];

    final trade = Trade(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      symbol: _symbol.text.trim().toUpperCase(),
      market: _market,
      direction: _direction,
      entryDate: DateTime.now(),
      timeframe: _timeframe,
      entryPrice: _doubleValue(_entryPrice),
      stopLoss: _doubleValue(_stopLoss),
      targets: targets,
      positionSize: _doubleValue(_positionSize),
      riskPercent: _doubleValue(_riskPercent),
      strategy: _strategy.text.trim(),
      reason: _reason.text.trim(),
      emotion: _emotion,
      status: _status,
      profitLoss: 0,
      notes: _notes.text.trim(),
      images: _imageNote.text.trim().isEmpty
          ? const []
          : [TradeImageNote(type: 'شروع معامله', note: _imageNote.text.trim())],
    );

    store.addTrade(trade);
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('معامله با موفقیت ثبت شد')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ثبت معامله جدید')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
          children: [
            _SectionTitle('اطلاعات اصلی'),
            TextFormField(
              controller: _symbol,
              validator: _required,
              decoration: const InputDecoration(labelText: 'نماد معامله'),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _market,
                    decoration: const InputDecoration(labelText: 'بازار'),
                    items: const [
                      DropdownMenuItem(value: 'کریپتو', child: Text('کریپتو')),
                      DropdownMenuItem(value: 'فارکس', child: Text('فارکس')),
                      DropdownMenuItem(value: 'بورس', child: Text('بورس')),
                      DropdownMenuItem(value: 'طلا', child: Text('طلا')),
                    ],
                    onChanged: (value) => setState(() => _market = value ?? _market),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _timeframe,
                    decoration: const InputDecoration(labelText: 'تایم‌فریم'),
                    items: const [
                      DropdownMenuItem(value: '1m', child: Text('1m')),
                      DropdownMenuItem(value: '5m', child: Text('5m')),
                      DropdownMenuItem(value: '15m', child: Text('15m')),
                      DropdownMenuItem(value: '30m', child: Text('30m')),
                      DropdownMenuItem(value: '1H', child: Text('1H')),
                      DropdownMenuItem(value: '4H', child: Text('4H')),
                      DropdownMenuItem(value: 'Daily', child: Text('Daily')),
                    ],
                    onChanged: (value) => setState(() => _timeframe = value ?? _timeframe),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<TradeDirection>(
                    value: _direction,
                    decoration: const InputDecoration(labelText: 'نوع معامله'),
                    items: const [
                      DropdownMenuItem(value: TradeDirection.buy, child: Text('خرید')),
                      DropdownMenuItem(value: TradeDirection.sell, child: Text('فروش')),
                    ],
                    onChanged: (value) => setState(() => _direction = value ?? _direction),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<TradeStatus>(
                    value: _status,
                    decoration: const InputDecoration(labelText: 'وضعیت'),
                    items: const [
                      DropdownMenuItem(value: TradeStatus.open, child: Text('باز')),
                      DropdownMenuItem(value: TradeStatus.closed, child: Text('بسته‌شده')),
                      DropdownMenuItem(value: TradeStatus.targetHit, child: Text('تارگت خورده')),
                      DropdownMenuItem(value: TradeStatus.stopHit, child: Text('استاپ خورده')),
                      DropdownMenuItem(value: TradeStatus.breakEven, child: Text('سربه‌سر')),
                    ],
                    onChanged: (value) => setState(() => _status = value ?? _status),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _SectionTitle('قیمت‌ها و مدیریت ریسک'),
            Row(
              children: [
                Expanded(child: _NumberField(controller: _entryPrice, label: 'قیمت ورود')),
                const SizedBox(width: 12),
                Expanded(child: _NumberField(controller: _stopLoss, label: 'حد ضرر')),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _NumberField(controller: _target1, label: 'تارگت 1')),
                const SizedBox(width: 12),
                Expanded(child: _NumberField(controller: _target2, label: 'تارگت 2')),
              ],
            ),
            const SizedBox(height: 12),
            ..._extraTargets.asMap().entries.map((entry) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _NumberField(controller: entry.value, label: 'تارگت ${entry.key + 3}'),
              );
            }),
            OutlinedButton.icon(
              onPressed: _addTargetField,
              icon: const Icon(Icons.add_rounded),
              label: const Text('افزودن تارگت بیشتر'),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _NumberField(controller: _positionSize, label: 'حجم معامله')),
                const SizedBox(width: 12),
                Expanded(child: _NumberField(controller: _riskPercent, label: 'درصد ریسک')),
              ],
            ),
            const SizedBox(height: 20),
            _SectionTitle('دلیل ورود و روانشناسی'),
            TextFormField(
              controller: _strategy,
              validator: _required,
              decoration: const InputDecoration(labelText: 'استراتژی'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _emotion,
              decoration: const InputDecoration(labelText: 'احساس قبل از معامله'),
              items: const [
                DropdownMenuItem(value: 'آرام', child: Text('آرام')),
                DropdownMenuItem(value: 'متمرکز', child: Text('متمرکز')),
                DropdownMenuItem(value: 'ترس', child: Text('ترس')),
                DropdownMenuItem(value: 'طمع', child: Text('طمع')),
                DropdownMenuItem(value: 'عجله', child: Text('عجله')),
                DropdownMenuItem(value: 'انتقام', child: Text('انتقام')),
              ],
              onChanged: (value) => setState(() => _emotion = value ?? _emotion),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _reason,
              validator: _required,
              minLines: 3,
              maxLines: 5,
              decoration: const InputDecoration(labelText: 'دلیل ورود'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _notes,
              minLines: 3,
              maxLines: 5,
              decoration: const InputDecoration(labelText: 'یادداشت معامله'),
            ),
            const SizedBox(height: 20),
            _SectionTitle('عکس و مستندات'),
            TextFormField(
              controller: _imageNote,
              minLines: 2,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'توضیح عکس شروع معامله',
                hintText: 'در نسخه بعد آپلود واقعی عکس اضافه می‌شود',
                prefixIcon: Icon(Icons.image_rounded),
              ),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save_rounded),
              label: const Text('ثبت معامله'),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.title);

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 4),
      child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
    );
  }
}

class _NumberField extends StatelessWidget {
  const _NumberField({required this.controller, required this.label});

  final TextEditingController controller;
  final String label;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      validator: (value) {
        if (value == null || value.trim().isEmpty) return 'لازم است';
        if (double.tryParse(value.trim().replaceAll(',', '.')) == null) return 'عدد معتبر نیست';
        return null;
      },
      decoration: InputDecoration(labelText: label),
    );
  }
}
