import 'package:flutter/material.dart';

import '../../core/widgets/section_card.dart';
import '../../data/models/trade.dart';
import '../../data/repositories/trade_store.dart';
import 'widgets/simple_charts.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  ReportRange _range = ReportRange.month;

  String get _rangeTitle {
    switch (_range) {
      case ReportRange.week:
        return 'هفتگی';
      case ReportRange.month:
        return 'ماهانه';
      case ReportRange.year:
        return 'سالانه';
      case ReportRange.all:
        return 'همه معاملات';
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);

    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final stats = store.stats(_range);
        final trades = store.tradesForRange(_range);

        return Scaffold(
          appBar: AppBar(title: const Text('گزارش و آمار')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
            children: [
              DropdownButtonFormField<ReportRange>(
                value: _range,
                decoration: const InputDecoration(labelText: 'بازه گزارش'),
                items: const [
                  DropdownMenuItem(value: ReportRange.week, child: Text('هفتگی')),
                  DropdownMenuItem(value: ReportRange.month, child: Text('ماهانه')),
                  DropdownMenuItem(value: ReportRange.year, child: Text('سالانه')),
                  DropdownMenuItem(value: ReportRange.all, child: Text('همه معاملات')),
                ],
                onChanged: (value) => setState(() => _range = value ?? _range),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'خلاصه $_rangeTitle',
                child: GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.35,
                  children: [
                    StatTile(title: 'کل معاملات', value: '${stats.total}', icon: Icons.timeline_rounded),
                    StatTile(title: 'معاملات بسته', value: '${stats.closed}', icon: Icons.done_all_rounded),
                    StatTile(
                      title: 'Win Rate',
                      value: '${stats.winRate.toStringAsFixed(0)}٪',
                      icon: Icons.percent_rounded,
                      positive: stats.winRate >= 50,
                    ),
                    StatTile(
                      title: 'سود خالص',
                      value: '${stats.netProfitLoss.toStringAsFixed(1)} دلار',
                      icon: Icons.account_balance_rounded,
                      positive: stats.netProfitLoss >= 0,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'نمودار رشد حساب',
                child: SizedBox(height: 190, child: EquityLineChart(trades: trades)),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'سود و ضرر معاملات اخیر',
                child: SizedBox(height: 180, child: ProfitBarChart(trades: trades)),
              ),
              const SizedBox(height: 18),
              SectionCard(
                title: 'تحلیل تارگت‌ها',
                child: Column(
                  children: [
                    _ProgressRow(label: 'رسیدن به تارگت 1', value: stats.target1Rate),
                    const SizedBox(height: 14),
                    _ProgressRow(label: 'رسیدن به تارگت 2', value: stats.target2Rate),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ProgressRow extends StatelessWidget {
  const _ProgressRow({required this.label, required this.value});

  final String label;
  final double value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700))),
            Text('${value.toStringAsFixed(0)}٪', style: const TextStyle(fontWeight: FontWeight.w900)),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: LinearProgressIndicator(
            minHeight: 10,
            value: value / 100,
            backgroundColor: const Color(0xFF0F172A),
          ),
        ),
      ],
    );
  }
}
