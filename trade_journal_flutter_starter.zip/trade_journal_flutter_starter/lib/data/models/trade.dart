enum TradeDirection { buy, sell }
enum TradeStatus { open, closed, targetHit, stopHit, breakEven }

enum ReportRange { week, month, year, all }

class TradeTarget {
  const TradeTarget({
    required this.title,
    required this.price,
    this.isHit = false,
  });

  final String title;
  final double price;
  final bool isHit;
}

class TradeImageNote {
  const TradeImageNote({
    required this.type,
    required this.note,
  });

  final String type;
  final String note;
}

class Trade {
  const Trade({
    required this.id,
    required this.symbol,
    required this.market,
    required this.direction,
    required this.entryDate,
    required this.timeframe,
    required this.entryPrice,
    required this.stopLoss,
    required this.targets,
    required this.positionSize,
    required this.riskPercent,
    required this.strategy,
    required this.reason,
    required this.emotion,
    required this.status,
    required this.images,
    this.exitDate,
    this.exitPrice,
    this.profitLoss = 0,
    this.notes = '',
  });

  final String id;
  final String symbol;
  final String market;
  final TradeDirection direction;
  final DateTime entryDate;
  final DateTime? exitDate;
  final String timeframe;
  final double entryPrice;
  final double stopLoss;
  final List<TradeTarget> targets;
  final double positionSize;
  final double riskPercent;
  final String strategy;
  final String reason;
  final String emotion;
  final TradeStatus status;
  final double? exitPrice;
  final double profitLoss;
  final String notes;
  final List<TradeImageNote> images;

  bool get isWin => profitLoss > 0;
  bool get isLoss => profitLoss < 0;
  bool get isClosed => status != TradeStatus.open;

  double get profitLossPercent {
    if (entryPrice == 0 || positionSize == 0) return 0;
    final base = entryPrice * positionSize;
    if (base == 0) return 0;
    return (profitLoss / base) * 100;
  }

  Trade copyWith({
    String? id,
    String? symbol,
    String? market,
    TradeDirection? direction,
    DateTime? entryDate,
    DateTime? exitDate,
    String? timeframe,
    double? entryPrice,
    double? stopLoss,
    List<TradeTarget>? targets,
    double? positionSize,
    double? riskPercent,
    String? strategy,
    String? reason,
    String? emotion,
    TradeStatus? status,
    double? exitPrice,
    double? profitLoss,
    String? notes,
    List<TradeImageNote>? images,
  }) {
    return Trade(
      id: id ?? this.id,
      symbol: symbol ?? this.symbol,
      market: market ?? this.market,
      direction: direction ?? this.direction,
      entryDate: entryDate ?? this.entryDate,
      exitDate: exitDate ?? this.exitDate,
      timeframe: timeframe ?? this.timeframe,
      entryPrice: entryPrice ?? this.entryPrice,
      stopLoss: stopLoss ?? this.stopLoss,
      targets: targets ?? this.targets,
      positionSize: positionSize ?? this.positionSize,
      riskPercent: riskPercent ?? this.riskPercent,
      strategy: strategy ?? this.strategy,
      reason: reason ?? this.reason,
      emotion: emotion ?? this.emotion,
      status: status ?? this.status,
      exitPrice: exitPrice ?? this.exitPrice,
      profitLoss: profitLoss ?? this.profitLoss,
      notes: notes ?? this.notes,
      images: images ?? this.images,
    );
  }
}

String directionLabel(TradeDirection value) {
  switch (value) {
    case TradeDirection.buy:
      return 'خرید';
    case TradeDirection.sell:
      return 'فروش';
  }
}

String statusLabel(TradeStatus value) {
  switch (value) {
    case TradeStatus.open:
      return 'باز';
    case TradeStatus.closed:
      return 'بسته‌شده';
    case TradeStatus.targetHit:
      return 'تارگت خورده';
    case TradeStatus.stopHit:
      return 'استاپ خورده';
    case TradeStatus.breakEven:
      return 'سربه‌سر';
  }
}
