enum TicketStatus { open, pending, answered, closed }

class SupportTicket {
  const SupportTicket({
    required this.id,
    required this.subject,
    required this.message,
    required this.status,
    required this.createdAt,
  });

  final String id;
  final String subject;
  final String message;
  final TicketStatus status;
  final DateTime createdAt;
}

String ticketStatusLabel(TicketStatus status) {
  switch (status) {
    case TicketStatus.open:
      return 'باز';
    case TicketStatus.pending:
      return 'در حال بررسی';
    case TicketStatus.answered:
      return 'پاسخ داده‌شده';
    case TicketStatus.closed:
      return 'بسته‌شده';
  }
}
