import 'package:flutter/material.dart';

import '../models/support_ticket.dart';
import '../models/trade.dart';

class AppScope extends InheritedNotifier<TradeStore> {
  const AppScope({
    super.key,
    required TradeStore store,
    required super.child,
  }) : super(notifier: store);

  static TradeStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope not found in context');
    return scope!.notifier!;
  }
}

class TradeStore extends ChangeNotifier {
  TradeStore({
    List<Trade>? trades,
    List<SupportTicket>? tickets,
  })  : _trades = trades ?? [],
        _tickets = tickets ?? [];

  factory TradeStore.seeded() {
    final now = DateTime.now();
    return TradeStore(
      trades: [
        Trade(
          id: '1',
          symbol: 'BTCUSDT',
          market: 'کریپتو',
          direction: TradeDirection.buy,
          entryDate: now.subtract(const Duration(days: 1)),
          exitDate: now.subtract(const Duration(hours: 18)),
          timeframe: '15m',
          entryPrice: 68400,
          stopLoss: 67950,
          targets: const [
            TradeTarget(title: 'تارگت 1', price: 69100, isHit: true),
            TradeTarget(title: 'تارگت 2', price: 69800, isHit: false),
          ],
          positionSize: 0.3,
          riskPercent: 1,
          strategy: 'پولبک به حمایت',
          reason: 'برگشت قیمت از محدوده حمایتی و تایید کندلی',
          emotion: 'آرام',
          status: TradeStatus.targetHit,
          exitPrice: 69100,
          profitLoss: 210,
          notes: 'ورود خوب بود ولی خروج کمی زود انجام شد.',
          images: const [
            TradeImageNote(type: 'شروع معامله', note: 'اسکرین‌شات چارت قبل از ورود'),
            TradeImageNote(type: 'خروج', note: 'قیمت بعد از تارگت اول برگشت'),
          ],
        ),
        Trade(
          id: '2',
          symbol: 'XAUUSD',
          market: 'فارکس',
          direction: TradeDirection.sell,
          entryDate: now.subtract(const Duration(days: 3)),
          exitDate: now.subtract(const Duration(days: 3, hours: -2)),
          timeframe: '1H',
          entryPrice: 2364,
          stopLoss: 2372,
          targets: const [
            TradeTarget(title: 'تارگت 1', price: 2356, isHit: false),
            TradeTarget(title: 'تارگت 2', price: 2348, isHit: false),
          ],
          positionSize: 1,
          riskPercent: 1.5,
          strategy: 'شکست ناموفق',
          reason: 'ورود بعد از شکست حمایت ولی بدون تایید کافی',
          emotion: 'عجله',
          status: TradeStatus.stopHit,
          exitPrice: 2372,
          profitLoss: -80,
          notes: 'ورود احساسی بود و خبر مهم هم نزدیک بود.',
          images: const [
            TradeImageNote(type: 'تحلیل', note: 'اسکرین‌شات محدوده شکست'),
          ],
        ),
        Trade(
          id: '3',
          symbol: 'EURUSD',
          market: 'فارکس',
          direction: TradeDirection.buy,
          entryDate: now.subtract(const Duration(days: 5)),
          exitDate: now.subtract(const Duration(days: 5, hours: -4)),
          timeframe: '30m',
          entryPrice: 1.0810,
          stopLoss: 1.0785,
          targets: const [
            TradeTarget(title: 'تارگت 1', price: 1.0840, isHit: true),
            TradeTarget(title: 'تارگت 2', price: 1.0870, isHit: true),
          ],
          positionSize: 10000,
          riskPercent: 1,
          strategy: 'روند صعودی',
          reason: 'هماهنگی روند تایم بالا و پولبک',
          emotion: 'متمرکز',
          status: TradeStatus.targetHit,
          exitPrice: 1.0870,
          profitLoss: 60,
          notes: 'معامله کاملاً طبق پلن انجام شد.',
          images: const [],
        ),
      ],
      tickets: [
        SupportTicket(
          id: 't1',
          subject: 'مشکل در ثبت عکس معامله',
          message: 'فعلاً آپلود واقعی در نسخه بعدی اضافه می‌شود.',
          status: TicketStatus.answered,
          createdAt: now.subtract(const Duration(days: 1)),
        ),
      ],
    );
  }

  final List<Trade> _trades;
  final List<SupportTicket> _tickets;

  List<Trade> get trades => List.unmodifiable(_trades);
  List<SupportTicket> get tickets => List.unmodifiable(_tickets);

  void addTrade(Trade trade) {
    _trades.insert(0, trade);
    notifyListeners();
  }

  void addTicket(SupportTicket ticket) {
    _tickets.insert(0, ticket);
    notifyListeners();
  }

  List<Trade> tradesForRange(ReportRange range) {
    final now = DateTime.now();
    DateTime? from;
    switch (range) {
      case ReportRange.week:
        from = now.subtract(const Duration(days: 7));
        break;
      case ReportRange.month:
        from = DateTime(now.year, now.month, 1);
        break;
      case ReportRange.year:
        from = DateTime(now.year, 1, 1);
        break;
      case ReportRange.all:
        from = null;
        break;
    }
    if (from == null) return trades;
    return _trades.where((trade) => trade.entryDate.isAfter(from!)).toList();
  }

  ReportStats stats(ReportRange range) {
    final filtered = tradesForRange(range);
    final closed = filtered.where((trade) => trade.isClosed).toList();
    final wins = closed.where((trade) => trade.isWin).length;
    final losses = closed.where((trade) => trade.isLoss).length;
    final net = closed.fold<double>(0, (sum, trade) => sum + trade.profitLoss);
    final grossProfit = closed.where((trade) => trade.isWin).fold<double>(0, (sum, trade) => sum + trade.profitLoss);
    final grossLoss = closed.where((trade) => trade.isLoss).fold<double>(0, (sum, trade) => sum + trade.profitLoss.abs());
    final target1Hits = filtered.where((trade) => trade.targets.isNotEmpty && trade.targets.first.isHit).length;
    final target2Hits = filtered.where((trade) => trade.targets.length > 1 && trade.targets[1].isHit).length;

    return ReportStats(
      total: filtered.length,
      closed: closed.length,
      wins: wins,
      losses: losses,
      netProfitLoss: net,
      grossProfit: grossProfit,
      grossLoss: grossLoss,
      target1Hits: target1Hits,
      target2Hits: target2Hits,
    );
  }
}

class ReportStats {
  const ReportStats({
    required this.total,
    required this.closed,
    required this.wins,
    required this.losses,
    required this.netProfitLoss,
    required this.grossProfit,
    required this.grossLoss,
    required this.target1Hits,
    required this.target2Hits,
  });

  final int total;
  final int closed;
  final int wins;
  final int losses;
  final double netProfitLoss;
  final double grossProfit;
  final double grossLoss;
  final int target1Hits;
  final int target2Hits;

  double get winRate => closed == 0 ? 0 : (wins / closed) * 100;
  double get target1Rate => total == 0 ? 0 : (target1Hits / total) * 100;
  double get target2Rate => total == 0 ? 0 : (target2Hits / total) * 100;
}
